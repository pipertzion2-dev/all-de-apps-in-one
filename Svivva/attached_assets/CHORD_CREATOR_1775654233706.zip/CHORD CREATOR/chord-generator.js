/**
 * ChordKit — embeddable chord generator for Replit / static HTML / bundlers.
 *
 * Style tags include: steely-dan, quincy-jones, jobim (bossa), tom-johnson (minimal
 * ensemble colors; not the same as Antonio Carlos Jobim — use `jobim` for bossa).
 *
 * Embed (global):
 *   <script src="chord-generator.js"></script>
 *   ChordKit.list({ tag: 'steely-dan' }); ChordKit.notes('D', 'mu_major');
 *
 * Embed (ES module):
 *   import * as ChordKit from './chord-generator.js';
 */
(function (global) {
  'use strict';

  var NOTE_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  var NOTE_FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];

  function parseRoot(root) {
    if (typeof root === 'number' && root >= 0 && root <= 11) return root;
    var s = String(root).trim();
    if (!s) return 0;
    var m = s.match(/^([A-Ga-g])([#b♯♭]?)/);
    if (!m) return 0;
    var letter = m[1].toUpperCase();
    var acc = m[2];
    var base = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[letter];
    if (acc === '#' || acc === '♯') base = (base + 1) % 12;
    if (acc === 'b' || acc === '♭') base = (base + 11) % 12;
    return base;
  }

  function rootLabel(pc, preferFlats) {
    var names = preferFlats ? NOTE_FLAT : NOTE_SHARP;
    return names[((pc % 12) + 12) % 12];
  }

  function uniqSortedIntervals(arr) {
    var seen = {};
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var n = ((arr[i] % 12) + 12) % 12;
      if (!seen[n]) {
        seen[n] = true;
        out.push(n);
      }
    }
    return out.sort(function (a, b) { return a - b; });
  }

  function mergeIntervals(base, add) {
    var all = base.slice();
    for (var i = 0; i < add.length; i++) all.push(add[i]);
    return uniqSortedIntervals(all);
  }

  /**
   * Map sorted pitch-class set (0–11, first tone = root class) to rising semitone offsets from root.
   * Each voice is the smallest pitch at or above the previous voice that matches its pitch class.
   */
  function intervalsToSemitonesFromRoot(intervals) {
    if (!intervals.length) return [];
    var semis = [intervals[0]];
    for (var i = 1; i < intervals.length; i++) {
      var t = intervals[i];
      var prev = semis[semis.length - 1];
      var candidate = t;
      while (candidate <= prev) candidate += 12;
      semis.push(candidate);
    }
    return semis;
  }

  function spellNotes(rootPc, intervals, options) {
    options = options || {};
    var preferFlats = options.preferFlats;
    var names = preferFlats ? NOTE_FLAT : NOTE_SHARP;
    var rootName = rootLabel(rootPc, preferFlats);
    var semis = intervalsToSemitonesFromRoot(intervals);
    var out = [];
    for (var i = 0; i < semis.length; i++) {
      var pc = (rootPc + semis[i]) % 12;
      if (pc < 0) pc += 12;
      out.push(names[pc]);
    }
    return { rootName: rootName, notes: out, midi: semis.map(function (s) { return 60 + rootPc + s; }) };
  }

  var registry = {};
  var listCache = null;

  function register(id, symbol, name, intervals, tags) {
    if (registry[id]) return;
    registry[id] = {
      id: id,
      symbol: symbol,
      name: name,
      intervals: uniqSortedIntervals(intervals),
      tags: tags || []
    };
  }

  function addTag(tags, t) {
    if (tags.indexOf(t) === -1) tags.push(t);
  }

  /* ——— Core triads & sus ——— */
  register('maj', '', 'Major triad', [0, 4, 7], ['triad', 'basic']);
  register('min', 'm', 'Minor triad', [0, 3, 7], ['triad', 'basic', 'brazilian', 'neo-soul', 'gospel']);
  register('dim', 'dim', 'Diminished triad', [0, 3, 6], ['triad', 'basic', 'jazz']);
  register('aug', 'aug', 'Augmented triad', [0, 4, 8], ['triad', 'basic', 'jazz']);
  register('sus2', 'sus2', 'Suspended 2nd', [0, 2, 7], ['triad', 'sus', 'neo-soul']);
  register('sus4', 'sus4', 'Suspended 4th', [0, 5, 7], ['triad', 'sus', 'gospel', 'brazilian']);
  register('add9', 'add9', 'Add 9', [0, 4, 7, 14], ['triad', 'extension', 'neo-soul']);
  register('madd9', 'madd9', 'Minor add 9', [0, 3, 7, 14], ['triad', 'extension', 'brazilian', 'neo-soul']);

  /* ——— Seventh chords ——— */
  register('maj7', 'maj7', 'Major 7th', [0, 4, 7, 11], ['7th', 'jazz', 'brazilian', 'neo-soul']);
  register('min7', 'm7', 'Minor 7th', [0, 3, 7, 10], ['7th', 'jazz', 'brazilian', 'neo-soul', 'gospel']);
  register('dom7', '7', 'Dominant 7th', [0, 4, 7, 10], ['7th', 'jazz', 'brazilian', 'gospel']);
  register('min7b5', 'm7♭5', 'Half-diminished', [0, 3, 6, 10], ['7th', 'jazz', 'brazilian']);
  register('dim7', 'dim7', 'Diminished 7th', [0, 3, 6, 9], ['7th', 'jazz', 'gospel']);
  register('mM7', 'mM7', 'Minor-major 7th', [0, 3, 7, 11], ['7th', 'jazz', 'brazilian', 'neo-soul']);
  register('aug7', 'aug7', 'Augmented 7th', [0, 4, 8, 10], ['7th', 'jazz']);
  register('maj7sus4', 'maj7sus4', 'Major 7 sus4', [0, 5, 7, 11], ['7th', 'sus', 'neo-soul']);
  register('7sus4', '7sus4', 'Dominant 7 sus4', [0, 5, 7, 10], ['7th', 'sus', 'gospel', 'neo-soul']);

  /* ——— Sixth / 6-9 (MPB & jazz) ——— */
  register('maj6', '6', 'Major 6th', [0, 4, 7, 9], ['6th', 'brazilian', 'jazz']);
  register('min6', 'm6', 'Minor 6th', [0, 3, 7, 9], ['6th', 'brazilian', 'jazz']);
  register('maj69', '6/9', 'Major 6/9', [0, 4, 7, 9, 14], ['6th', 'brazilian', 'neo-soul', 'jazz']);
  register('min69', 'm6/9', 'Minor 6/9', [0, 3, 7, 9, 14], ['6th', 'brazilian', 'neo-soul']);

  /* ——— Ninth family ——— */
  register('maj9', 'maj9', 'Major 9th', [0, 4, 7, 11, 14], ['9th', 'jazz', 'brazilian', 'neo-soul']);
  register('min9', 'm9', 'Minor 9th', [0, 3, 7, 10, 14], ['9th', 'jazz', 'brazilian', 'neo-soul', 'gospel']);
  register('dom9', '9', 'Dominant 9th', [0, 4, 7, 10, 14], ['9th', 'jazz', 'brazilian', 'gospel']);
  register('maj7b9', 'maj7♭9', 'Major 7 ♭9', [0, 4, 7, 11, 13], ['9th', 'altered', 'exotic']);
  register('min7b9', 'm7♭9', 'Minor 7 ♭9', [0, 3, 7, 10, 13], ['9th', 'altered', 'brazilian', 'jazz']);
  register('7b9', '7♭9', 'Dominant 7 ♭9', [0, 4, 7, 10, 13], ['9th', 'altered', 'jazz', 'brazilian', 'gospel']);
  register('7sharp9', '7♯9', 'Dominant 7 ♯9', [0, 4, 7, 10, 15], ['9th', 'altered', 'jazz', 'neo-soul']);
  register('mM9', 'mM9', 'Minor-major 9', [0, 3, 7, 11, 14], ['9th', 'jazz', 'brazilian', 'neo-soul']);
  register('maj9sus4', 'maj9sus4', 'Maj9 sus4', [0, 5, 7, 11, 14], ['9th', 'sus', 'neo-soul']);

  /* ——— Eleventh family ——— */
  register('min11', 'm11', 'Minor 11th', [0, 3, 7, 10, 14, 17], ['11th', 'jazz', 'brazilian', 'neo-soul', 'gospel']);
  register('dom11', '11', 'Dominant 11th', [0, 4, 7, 10, 14, 17], ['11th', 'jazz']);
  register('maj7sharp11', 'maj7♯11', 'Lydian major 7', [0, 4, 7, 11, 18], ['11th', 'jazz', 'brazilian', 'neo-soul']);
  register('7sharp11', '7♯11', 'Dominant 7 ♯11', [0, 4, 7, 10, 18], ['11th', 'altered', 'jazz', 'brazilian']);
  register('min11omit9', 'm11(omit9)', 'Minor 11 (no 9)', [0, 3, 7, 10, 17], ['11th', 'neo-soul', 'piano']);

  /* ——— Thirteenth family ——— */
  register('maj13', 'maj13', 'Major 13th', [0, 4, 7, 11, 14, 21], ['13th', 'jazz', 'brazilian']);
  register('min13', 'm13', 'Minor 13th', [0, 3, 7, 10, 14, 21], ['13th', 'jazz', 'neo-soul', 'gospel']);
  register('dom13', '13', 'Dominant 13th', [0, 4, 7, 10, 14, 21], ['13th', 'jazz', 'brazilian', 'gospel']);
  register('maj13sharp11', 'maj13♯11', 'Major 13 ♯11', [0, 4, 7, 11, 14, 18, 21], ['13th', 'jazz', 'brazilian', 'ivan-lins']);
  register('13sharp11', '13♯11', 'Dominant 13 ♯11', [0, 4, 7, 10, 14, 18, 21], ['13th', 'jazz', 'brazilian']);
  register('7b13', '7♭13', 'Dominant 7 ♭13', [0, 4, 7, 10, 20], ['13th', 'altered', 'jazz']);
  register('7b9b13', '7♭9♭13', 'Dominant altered', [0, 4, 7, 10, 13, 20], ['13th', 'altered', 'jazz', 'brazilian']);
  register('7sharp9b13', '7♯9♭13', 'Dominant ♯9 ♭13', [0, 4, 7, 10, 15, 20], ['13th', 'altered', 'neo-soul']);
  register('alt', 'alt', 'Altered scale chord', [0, 4, 8, 10, 13, 15, 18, 20], ['altered', 'jazz', 'neo-soul', 'glasper']);

  /* ——— Quartal / stacked 4ths (common in modern jazz & neo-soul) ——— */
  register('quartal3', 'quartal(3)', 'Three-note quartal', [0, 5, 10], ['quartal', 'neo-soul', 'piano']);
  register('quartal4', 'quartal(4)', 'Four-note quartal', [0, 5, 10, 15], ['quartal', 'neo-soul', 'glasper']);
  register('quartal5', 'quartal(5)', 'Five-note quartal', [0, 5, 10, 15, 20], ['quartal', 'neo-soul']);

  /* ——— Poly / slash-style sonorities (intervals from bass; use slash in your UI) ——— */
  register('maj_over_sharp5', 'maj(♯5)', 'Major ♯5', [0, 4, 8], ['triad', 'lydian', 'neo-soul']);
  register('maj7sharp5', 'maj7♯5', 'Major 7 ♯5', [0, 4, 8, 11], ['7th', 'lydian', 'neo-soul']);
  register('minmaj9sharp11', 'mM9♯11', 'Minor-major 9 ♯11', [0, 3, 7, 11, 14, 18], ['extension', 'exotic', 'neo-soul']);

  /* ——— Gospel / cluster presets (semitones within octave; dense = cluster) ——— */
  register('cluster_maj2', 'cluster(maj2)', 'Major 2nd cluster', [0, 2, 4], ['cluster', 'gospel', 'dense']);
  register('cluster_min3', 'cluster(min3)', 'Minor 3rd stack', [0, 3, 6], ['cluster', 'gospel']);
  register('cluster_4_half', 'cluster(½)', 'Half-step cluster', [0, 1, 2], ['cluster', 'gospel', 'dense']);
  register('cluster_dom_shell', 'shell+cluster', 'Dom shell tight', [0, 4, 7, 10, 11], ['cluster', 'gospel', 'dense']);
  register('spread_triad_add2', 'add2 spread', 'Add-2 color', [0, 2, 4, 7], ['gospel', 'neo-soul']);
  register('power5', '5', 'Power (fifth)', [0, 7], ['basic', 'rock']);

  /* Generate dominant alterations (combinations of b9 #9 #11 b13 on dom7) */
  var domBase = [0, 4, 7, 10];
  var altTones = [
    { semi: 13, sym: '♭9' },
    { semi: 14, sym: '9' },
    { semi: 15, sym: '♯9' },
    { semi: 17, sym: '11' },
    { semi: 18, sym: '♯11' },
    { semi: 20, sym: '♭13' },
    { semi: 21, sym: '13' }
  ];
  var genTags = ['generated', 'dominant', 'jazz'];

  function bitmaskToAlts(mask) {
    var parts = [];
    var semis = [];
    for (var b = 0; b < altTones.length; b++) {
      if (mask & (1 << b)) {
        parts.push(altTones[b].sym.replace(/♭/g, 'b').replace(/♯/g, 's'));
        semis.push(altTones[b].semi);
      }
    }
    return { parts: parts, semis: semis };
  }

  for (var mask = 1; mask < 128; mask++) {
    var info = bitmaskToAlts(mask);
    if (info.semis.length > 5) continue;
    var id = 'dom7alt_' + info.parts.join('_');
    if (id.length > 48) id = 'dom7alt_' + mask;
    var sym = '7(' + info.parts.join(',') + ')';
    var intervals = mergeIntervals(domBase, info.semis);
    var tags = genTags.slice();
    addTag(tags, 'neo-soul');
    addTag(tags, 'glasper');
    addTag(tags, 'steely-dan');
    addTag(tags, 'quincy-jones');
    addTag(tags, 'studio');
    register(id, sym, 'Dominant altered combination', intervals, tags);
  }

  /* maj7 + optional 9 #11 13 combinations */
  var maj7b = [0, 4, 7, 11];
  var majExt = [
    { semi: 14, sym: '9' },
    { semi: 18, sym: '♯11' },
    { semi: 21, sym: '13' }
  ];
  for (var m2 = 1; m2 < 8; m2++) {
    var parts2 = [];
    var sem2 = [];
    for (var b2 = 0; b2 < 3; b2++) {
      if (m2 & (1 << b2)) {
        parts2.push(majExt[b2].sym.replace(/♯/g, '#'));
        sem2.push(majExt[b2].semi);
      }
    }
    if (!sem2.length) continue;
    var id2 = 'maj7ext_' + parts2.join('_');
    register(
      id2,
      'maj7(' + parts2.join(',') + ')',
      'Major 7 extended',
      mergeIntervals(maj7b, sem2),
      ['maj7', 'generated', 'brazilian', 'ivan-lins', 'steely-dan', 'quincy-jones', 'studio']
    );
  }

  /* min7 + 9, 11, b13 combinations (common in MPB) */
  var min7b = [0, 3, 7, 10];
  var minExt = [
    { semi: 14, sym: '9' },
    { semi: 17, sym: '11' },
    { semi: 20, sym: '♭13' }
  ];
  for (var m3 = 1; m3 < 8; m3++) {
    var parts3 = [];
    var sem3 = [];
    for (var b3 = 0; b3 < 3; b3++) {
      if (m3 & (1 << b3)) {
        parts3.push(minExt[b3].sym.replace(/♭/g, 'b').replace(/♯/g, '#'));
        sem3.push(minExt[b3].semi);
      }
    }
    register(
      'min7ext_' + parts3.join('_'),
      'm7(' + parts3.join(',') + ')',
      'Minor 7 extended',
      mergeIntervals(min7b, sem3),
      ['m7', 'generated', 'brazilian', 'neo-soul', 'quincy-jones', 'studio']
    );
  }

  /* Additional explicit “Ivan Lins / MPB” colors */
  register('maj7b6', 'maj7♭6', 'Major 7 ♭6', [0, 4, 7, 8, 11], ['brazilian', 'ivan-lins', 'jazz']);
  register('minmaj7add11', 'mM7add11', 'Minor-major 7 add 11', [0, 3, 7, 11, 17], ['brazilian', 'neo-soul', 'jazz']);
  register('dom7b5', '7♭5', 'Dominant 7 ♭5', [0, 4, 6, 10], ['7th', 'jazz', 'brazilian']);
  register('dom7sharp5', '7♯5', 'Dominant 7 ♯5', [0, 4, 8, 10], ['7th', 'jazz']);
  register('9sus4', '9sus4', '9 sus4', [0, 2, 5, 7, 10], ['sus', 'gospel', 'neo-soul']);
  register('13sus4', '13sus4', '13 sus4', [0, 5, 7, 10, 14, 21], ['sus', 'gospel', 'jazz']);

  /* ——— Steely Dan / LA studio jazz-rock ——— */
  register('mu_major', 'add2', 'Mu major (add 2)', [0, 2, 4, 7], ['steely-dan', 'studio', 'add2']);
  register('maj7add2', 'maj7(add2)', 'Major 7 add 2', [0, 2, 4, 7, 11], ['steely-dan', 'studio', 'add2']);
  register('maj9omit3', 'maj9(omit3)', 'Major 9 (no 3rd)', [0, 11, 14], ['steely-dan', 'studio', 'exotic']);
  register('maj7omit3addsharp11', 'maj7(omit3)♯11', 'Lydian float (no 3)', [0, 11, 18], ['steely-dan', 'studio']);
  register('7sharp9sharp5', '7♯9♯5', 'Dominant ♯9 ♯5', [0, 4, 8, 10, 15], ['steely-dan', 'altered', 'studio']);
  register('7b9sharp11', '7♭9♯11', 'Dominant ♭9 ♯11', [0, 4, 7, 10, 13, 18], ['steely-dan', 'jazz', 'studio']);
  register('7sharp9sharp11', '7♯9♯11', 'Dominant ♯9 ♯11', [0, 4, 7, 10, 15, 18], ['steely-dan', 'altered']);
  register('7b9sharp5', '7♭9♯5', 'Dominant ♭9 ♯5', [0, 4, 8, 10, 13], ['steely-dan', 'altered']);
  register('maj7sharp5add9', 'maj7♯5(add9)', 'Major 7 ♯5 add 9', [0, 4, 8, 11, 14], ['steely-dan', 'studio', 'lydian']);
  register('maj7addsharp13', 'maj7(add♯13)', 'Major 7 add ♯13', [0, 4, 7, 11, 22], ['steely-dan', 'studio']);
  register('minadd11', 'madd11', 'Minor add 11', [0, 3, 5, 7], ['steely-dan', 'jazz', 'studio']);
  register('minadd9omit5', 'madd9(no5)', 'Minor add 9 omit 5', [0, 3, 14], ['steely-dan', 'studio']);
  register('sus13flat9', '13sus♭9', '13 sus ♭9', [0, 5, 7, 10, 13, 21], ['steely-dan', 'quincy-jones', 'studio']);
  register('maj69omit3', '6/9(omit3)', 'Six-nine (no 3rd)', [0, 9, 14], ['steely-dan', 'studio', 'exotic']);
  register('dom7omit5', '7(no5)', 'Dominant 7 omit 5', [0, 4, 10], ['steely-dan', 'studio', 'jobim']);
  register('dom9omit5', '9(no5)', 'Dominant 9 omit 5', [0, 4, 10, 14], ['steely-dan', 'quincy-jones', 'studio']);
  register('maj13omit9', 'maj13(omit9)', 'Major 13 omit 9', [0, 4, 7, 11, 21], ['steely-dan', 'studio']);
  register('min11omit7', 'm11(omit7)', 'Minor 11 omit 7', [0, 3, 7, 14, 17], ['steely-dan', 'studio']);
  register('7sharp11omit5', '7♯11(no5)', 'Dominant ♯11 omit 5', [0, 4, 10, 18], ['steely-dan', 'jazz']);
  register('maj7add6', 'maj7(add6)', 'Major 7 add 6', [0, 4, 7, 9, 11], ['steely-dan', 'studio']);
  register('min7add4', 'm7(add4)', 'Minor 7 add 4', [0, 3, 5, 7, 10], ['steely-dan', 'studio']);

  /* ——— Antonio Carlos Jobim / classic bossa changes ——— */
  register('maj7flat5', 'maj7♭5', 'Major 7 ♭5', [0, 4, 6, 11], ['jobim', 'brazilian', 'jazz']);
  register('min9omit5', 'm9(no5)', 'Minor 9 omit 5', [0, 3, 10, 14], ['jobim', 'brazilian', 'studio']);
  register('dom7b9omit5', '7♭9(no5)', 'Dominant ♭9 omit 5', [0, 4, 10, 13], ['jobim', 'brazilian']);
  register('maj7add13', 'maj7(add13)', 'Major 7 add 13', [0, 4, 7, 11, 21], ['jobim', 'brazilian', 'ivan-lins']);
  register('dim7pass', 'dim7(pass)', 'Diminished passing (4-note)', [0, 3, 6, 9], ['jobim', 'brazilian', 'jazz']);
  register('min11omit5', 'm11(no5)', 'Minor 11 omit 5', [0, 3, 10, 14, 17], ['jobim', 'brazilian', 'studio']);
  register('maj7sharp11sharp5', 'maj7♯11♯5', 'Lydian augmented color', [0, 4, 8, 11, 18], ['jobim', 'brazilian', 'steely-dan', 'studio']);
  register('dom7sharp11sharp9', '7♯11♯9', 'Dominant ♯11 ♯9', [0, 4, 7, 10, 15, 18], ['quincy-jones', 'steely-dan', 'altered']);
  register('maj9sharp11', 'maj9♯11', 'Major 9 ♯11', [0, 4, 7, 11, 14, 18], ['quincy-jones', 'steely-dan', 'studio']);
  register('min9sharp11', 'm9♯11', 'Minor 9 ♯11', [0, 3, 7, 10, 14, 18], ['neo-soul', 'quincy-jones', 'studio']);
  register('dom7omit3', '7(no3)', 'Dominant 7 omit 3 (power-blues shell)', [0, 7, 10], ['steely-dan', 'studio']);
  register('dom9omit3', '9(no3)', 'Dominant 9 omit 3', [0, 7, 10, 14], ['quincy-jones', 'studio']);

  /* ——— Tom Johnson–style minimal / analytical sonorities (ensemble colors) ——— */
  register('tj_open4', 'open4', 'Open fourth dyad', [0, 5], ['tom-johnson', 'minimal', 'studio']);
  register('tj_open5', 'open5+', 'Open fifth + add-2', [0, 2, 7], ['tom-johnson', 'minimal', 'studio']);
  register('tj_trichord_014', '014', 'Trichord 0-1-4', [0, 1, 4], ['tom-johnson', 'minimal', 'dense']);
  register('tj_trichord_015', '015', 'Trichord 0-1-5', [0, 1, 5], ['tom-johnson', 'minimal']);
  register('tj_sec5', '♭2+5', 'Minor 2nd with fifth', [0, 1, 7], ['tom-johnson', 'minimal', 'dense']);
  register('tj_quartal3', 'quartal(3)', 'Three-note quartal (TJ tag)', [0, 5, 10], ['tom-johnson', 'quartal', 'studio']);

  /* Upper-structure triads over dominant shell (Quincy / LA session voicing vocabulary) */
  function triadPitchClasses(qual, rootDeg) {
    var d = ((rootDeg % 12) + 12) % 12;
    if (qual === 'M') return [d, (d + 4) % 12, (d + 7) % 12];
    if (qual === 'm') return [d, (d + 3) % 12, (d + 7) % 12];
    if (qual === 'dim') return [d, (d + 3) % 12, (d + 6) % 12];
    return [d, (d + 4) % 12, (d + 8) % 12];
  }

  var usDegLabels = { 1: '♭9', 2: '9', 3: '♯9', 5: '11', 6: '♯11', 8: '♭13', 9: '13', 10: '♭7', 11: 'M7' };
  var usDegrees = [1, 2, 3, 5, 6, 8, 9, 11];
  var usQuals = [
    { q: 'M', lab: 'maj' },
    { q: 'm', lab: 'min' },
    { q: 'dim', lab: 'dim' },
    { q: 'aug', lab: 'aug' }
  ];
  for (var ui = 0; ui < usDegrees.length; ui++) {
    var deg = usDegrees[ui];
    var lab = usDegLabels[deg] || String(deg);
    for (var uq = 0; uq < usQuals.length; uq++) {
      var qu = usQuals[uq];
      var tpcs = triadPitchClasses(qu.q, deg);
      var merged = mergeIntervals(domBase, tpcs);
      if (merged.length < 5) continue;
      var idUs = 'us7_' + qu.lab + '_r' + deg;
      var symUs = '7/' + qu.lab + '(' + lab + ')';
      register(
        idUs,
        symUs,
        'Dominant + upper ' + qu.lab + ' on ' + lab,
        merged,
        ['quincy-jones', 'upper-structure', 'studio', 'steely-dan', 'generated-us']
      );
    }
  }

  /* Dominant + upper-structure on ♭II (tritone-related) — common Steely / session color */
  var domShellNoRoot = [4, 7, 10];
  var tritoneTriads = [
    { q: 'M', pcs: triadPitchClasses('M', 1) },
    { q: 'm', pcs: triadPitchClasses('m', 1) }
  ];
  for (var ti = 0; ti < tritoneTriads.length; ti++) {
    var tt = tritoneTriads[ti];
    var idTt = 'us7_tt_' + tt.q + '_bII';
    register(
      idTt,
      '7/' + tt.q + '(♭II)',
      'Dom shell + triad from ♭II',
      mergeIntervals(domShellNoRoot, tt.pcs),
      ['steely-dan', 'quincy-jones', 'upper-structure', 'tritone', 'studio']
    );
  }

  function invalidateListCache() {
    listCache = null;
  }

  function getAll() {
    if (!listCache) {
      listCache = Object.keys(registry).map(function (k) { return registry[k]; });
      listCache.sort(function (a, b) { return a.name.localeCompare(b.name); });
    }
    return listCache.slice();
  }

  function list(filters) {
    filters = filters || {};
    var all = getAll();
    return all.filter(function (c) {
      if (filters.tag && c.tags.indexOf(filters.tag) === -1) return false;
      if (filters.q) {
        var q = String(filters.q).toLowerCase();
        if (c.id.toLowerCase().indexOf(q) === -1 && c.name.toLowerCase().indexOf(q) === -1 && c.symbol.toLowerCase().indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function get(id) {
    return registry[id] || null;
  }

  function notes(root, chordId, options) {
    var def = get(chordId);
    if (!def) return null;
    var pc = parseRoot(root);
    return spellNotes(pc, def.intervals, options);
  }

  /** MIDI note numbers from C4=60, close stack */
  function midiVoicing(root, chordId, baseOctave) {
    baseOctave = baseOctave == null ? 4 : baseOctave;
    var n = notes(root, chordId, {});
    if (!n) return [];
    var rootMidi = 12 * (baseOctave + 1) + parseRoot(root);
    var offs = intervalsToSemitonesFromRoot(get(chordId).intervals);
    return offs.map(function (s) {
      return rootMidi + s;
    });
  }

  function invertPitchClasses(pcs, inversion) {
    inversion = inversion || 0;
    var arr = pcs.slice().sort(function (a, b) { return a - b; });
    var n = arr.length;
    var inv = inversion % n;
    if (inv < 0) inv += n;
    var out = [];
    for (var i = 0; i < n; i++) {
      out.push(arr[(i + inv) % n]);
    }
    return out;
  }

  /**
   * Gospel / piano spread: invert chord tones and spread across octaves.
   * inversion: 0..n-1 bass rotation on pitch classes
   * spread: extra octave gaps between voices (0 = close)
   */
  function voicing(root, chordId, opts) {
    opts = opts || {};
    var def = get(chordId);
    if (!def) return null;
    var pc = parseRoot(root);
    var inv = opts.inversion || 0;
    var spread = opts.spread || 0;
    var pcs = def.intervals.map(function (x) { return (pc + x) % 12; });
    var order = invertPitchClasses(pcs, inv);
    var midi = [];
    var octave = opts.octave == null ? 3 : opts.octave;
    var base = 12 * (octave + 1);
    var last = -1;
    for (var i = 0; i < order.length; i++) {
      var pitch = order[i];
      var m = base + pitch;
      while (m <= last) m += 12;
      m += spread * i * 12;
      while (m <= last) m += 12;
      midi.push(m);
      last = m;
    }
    var names = [];
    var useFlat = opts.preferFlats;
    for (var j = 0; j < midi.length; j++) {
      names.push(rootLabel(midi[j] % 12, useFlat));
    }
    return { midi: midi, notes: names, chordId: chordId, inversion: inv };
  }

  /** Random chord from optional tag (useful for practice UI) */
  function randomChord(tag) {
    var pool = tag ? list({ tag: tag }) : getAll();
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  /** e.g. displaySymbol('Db', 'min9') → "Dbm9" */
  function displaySymbol(root, chordId) {
    var def = get(chordId);
    if (!def) return String(root);
    var r = rootLabel(parseRoot(root), false);
    return r + (def.symbol || '');
  }

  /** Custom chord from semitone intervals (0 = root) */
  function registerCustom(id, symbol, name, intervals, tags) {
    register(id, symbol, name, intervals, tags);
    invalidateListCache();
  }

  var TAGS = [
    'basic', 'triad', '7th', '9th', '11th', '13th', 'altered', 'sus', 'quartal', 'cluster',
    'brazilian', 'ivan-lins', 'neo-soul', 'glasper', 'gospel', 'jazz', 'piano', 'generated',
    'steely-dan', 'quincy-jones', 'jobim', 'tom-johnson', 'studio', 'upper-structure', 'minimal',
    'generated-us', 'tritone', 'add2', 'lydian', 'exotic'
  ];

  var ChordKit = {
    parseRoot: parseRoot,
    rootLabel: rootLabel,
    list: list,
    get: get,
    getAll: getAll,
    notes: notes,
    midiVoicing: midiVoicing,
    voicing: voicing,
    randomChord: randomChord,
    displaySymbol: displaySymbol,
    registerCustom: registerCustom,
    TAGS: TAGS,
    /** Total registered chord types */
    count: function () { return Object.keys(registry).length; }
  };

  global.ChordKit = ChordKit;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChordKit;
  }
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : this);
