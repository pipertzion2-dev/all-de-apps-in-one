/**
 * AudioChordArranger — connect key/chord detection output to ChordKit for Replit.
 *
 * Load order (browser):
 *   <script src="chord-generator.js"></script>
 *   <script src="analysis-bridge.js"></script>
 *
 * Node:
 *   require('./chord-generator.js');
 *   const A = require('./analysis-bridge.js');
 */
(function (global) {
  'use strict';

  var CK = global.ChordKit;
  if (!CK) {
    throw new Error('ChordKit not found. Load chord-generator.js before analysis-bridge.js');
  }

  var ROOT_RE = /^([A-Ga-g])([#b\u266F\u266D\u266F\u266D♯♭]?)/;

  /** Expected shape you can POST from your analyzer (all fields optional except one chord list). */
  var EXAMPLE_PAYLOAD = {
    key: { root: 'Eb', mode: 'major' },
    tempoBpm: 92,
    timeSignature: [4, 4],
    chords: [
      { t0: 0, t1: 3.2, symbol: 'Ebmaj7' },
      { t0: 3.2, t1: 6.4, symbol: 'Cm7' },
      { t0: 6.4, t1: 9.6, symbol: 'Fm7' },
      { t0: 9.6, t1: 12.8, symbol: 'Bb7' }
    ]
  };

  function clamp(n, lo, hi) {
    return Math.max(lo, Math.min(hi, n));
  }

  function normalizeMode(m) {
    if (!m && m !== 0) return 'major';
    var s = String(m).toLowerCase().trim();
    if (s === 'maj' || s === 'major' || s === 'ionian') return 'major';
    if (s === 'min' || s === 'minor' || s === 'aeolian' || s === 'natural minor') return 'minor';
    return s.indexOf('min') >= 0 ? 'minor' : 'major';
  }

  /**
   * Normalize key from analyzer: string "Eb major", object { root, mode }, or { tonicPc, mode }.
   */
  function normalizeKey(keyInput) {
    if (keyInput == null) {
      return { rootStr: 'C', rootPc: 0, mode: 'major', scalePcs: scalePitchClasses(0, 'major') };
    }
    if (typeof keyInput === 'string') {
      var m = keyInput.trim().match(/^([A-Ga-g][#b♯♭]?)\s*(.*)$/);
      if (m) {
        return finalizeKey(m[1], normalizeMode(m[2] || 'major'));
      }
      return normalizeKey({ root: 'C', mode: 'major' });
    }
    var rootStr = keyInput.root || keyInput.tonic || keyInput.note || 'C';
    if (typeof keyInput.tonicPc === 'number') {
      var pc = ((keyInput.tonicPc % 12) + 12) % 12;
      rootStr = CK.rootLabel(pc, false);
      return finalizeKey(rootStr, normalizeMode(keyInput.mode));
    }
    return finalizeKey(String(rootStr), normalizeMode(keyInput.mode));
  }

  function finalizeKey(rootStr, mode) {
    var rootPc = CK.parseRoot(rootStr);
    return {
      rootStr: CK.rootLabel(rootPc, /b/.test(String(rootStr))),
      rootPc: rootPc,
      mode: mode,
      scalePcs: scalePitchClasses(rootPc, mode)
    };
  }

  function scalePitchClasses(rootPc, mode) {
    var major = [0, 2, 4, 5, 7, 9, 11];
    var naturalMinor = [0, 2, 3, 5, 7, 8, 10];
    var intervals = mode === 'minor' ? naturalMinor : major;
    return intervals.map(function (i) {
      return (rootPc + i) % 12;
    });
  }

  function parseRootToken(str) {
    var m = String(str).trim().match(ROOT_RE);
    if (!m) return null;
    var acc = m[2] || '';
    return m[1].toUpperCase() + acc.replace(/♯/g, '#').replace(/♭/g, 'b');
  }

  /**
   * Parse "F#m7/E" → { rootStr, bassStr|null, qualityRaw }.
   */
  function parseChordLabel(label) {
    var s = String(label || '').trim();
    if (!s) return null;
    var bassStr = null;
    var slash = s.lastIndexOf('/');
    if (slash > 0) {
      var maybeBass = s.slice(slash + 1).trim();
      if (parseRootToken(maybeBass)) {
        bassStr = parseRootToken(maybeBass);
        s = s.slice(0, slash).trim();
      }
    }
    var rm = s.match(ROOT_RE);
    if (!rm) return null;
    var rootStr = rm[1].toUpperCase() + (rm[2] || '').replace(/♯/g, '#').replace(/♭/g, 'b');
    var qualityRaw = s.slice(rm[0].length).trim();
    return { rootStr: rootStr, bassStr: bassStr, qualityRaw: qualityRaw };
  }

  function normalizeQuality(q) {
    var t = String(q || '').trim();
    if (!t) return '';
    t = t
      .replace(/\u0394/g, 'maj7')
      .replace(/△/g, 'maj7')
      .replace(/−/g, 'm')
      .replace(/\s+/g, '')
      .replace(/major/gi, 'maj')
      .replace(/minor/gi, 'min')
      .replace(/diminished/gi, 'dim')
      .replace(/augmented/gi, 'aug')
      .replace(/dominant/gi, '');
    t = t.toLowerCase();
    t = t.replace(/maj7/g, 'maj7').replace(/ma7/g, 'maj7').replace(/m7b5/g, 'm7b5');
    t = t.replace(/#11/g, 'sharp11').replace(/#9/g, 'sharp9').replace(/#5/g, 'sharp5');
    t = t.replace(/b9/g, 'b9').replace(/b13/g, 'b13').replace(/b5/g, 'b5');
    return t;
  }

  /**
   * Map normalized quality string → ChordKit id (best effort for detector output).
   */
  function qualityToChordId(qualityRaw) {
    var q = normalizeQuality(qualityRaw);
    if (q === '' || q === 'maj' || q === 'major') return 'maj';
    var table = {
      m: 'min',
      min: 'min',
      '-': 'min',
      dim: 'dim',
      o: 'dim',
      aug: 'aug',
      '+': 'aug',
      '5': 'power5',
      sus: 'sus4',
      sus2: 'sus2',
      sus4: 'sus4',
      add9: 'add9',
      '6': 'maj6',
      m6: 'min6',
      '6/9': 'maj69',
      '69': 'maj69',
      maj6: 'maj6',
      maj7: 'maj7',
      mmaj7: 'mM7',
      mma7: 'mM7',
      minmaj7: 'mM7',
      m7: 'min7',
      min7: 'min7',
      maj9: 'maj9',
      m9: 'min9',
      min9: 'min9',
      '9': 'dom9',
      '7': 'dom7',
      maj11: 'dom11',
      m11: 'min11',
      '11': 'dom11',
      maj13: 'maj13',
      m13: 'min13',
      '13': 'dom13',
      m7b5: 'min7b5',
      dim7: 'dim7',
      '7sus4': '7sus4',
      '9sus4': '9sus4',
      maj7sharp11: 'maj7sharp11',
      maj7s11: 'maj7sharp11',
      '7sharp11': '7sharp11',
      '7#11': '7sharp11',
      '7b9': '7b9',
      '7sharp9': '7sharp9',
      '7#9': '7sharp9',
      maj69: 'maj69',
      mu: 'mu_major',
      add2: 'mu_major',
      quartal3: 'quartal3'
    };
    if (table[q]) return table[q];
    if (CK.get(q)) return q;
    if (q.indexOf('maj13') >= 0 && q.indexOf('sharp11') >= 0) return 'maj13sharp11';
    if (q.indexOf('13') >= 0 && q.indexOf('sharp11') >= 0) return '13sharp11';
    if (q.indexOf('maj7') >= 0 && q.indexOf('sharp11') >= 0) return 'maj7sharp11';
    if (q.indexOf('m7') >= 0 && q.indexOf('b5') >= 0) return 'min7b5';
    if (q.indexOf('maj7') >= 0 && q.indexOf('b5') >= 0) return 'maj7flat5';
    if (q.indexOf('maj9') >= 0 && q.indexOf('sharp11') >= 0) return 'maj9sharp11';
    if (q.indexOf('m9') >= 0 && q.indexOf('sharp11') >= 0) return 'min9sharp11';
    if (q.indexOf('maj7') >= 0 && q.indexOf('add2') >= 0) return 'maj7add2';
    if (q === 'maj9omit3' || q === 'maj9(no3)') return 'maj9omit3';
    return null;
  }

  function resolveChordId(parsed) {
    if (!parsed) return { chordId: null, warning: 'empty label' };
    var id = qualityToChordId(parsed.qualityRaw);
    if (!id) {
      return {
        chordId: null,
        warning: 'unknown quality "' + parsed.qualityRaw + '" for ChordKit mapping'
      };
    }
    if (!CK.get(id)) {
      return { chordId: null, warning: 'ChordKit missing id "' + id + '"' };
    }
    return { chordId: id, warning: null };
  }

  function degreeInKey(chordRootPc, key) {
    var diff = (chordRootPc - key.rootPc + 12) % 12;
    var major = [0, 2, 4, 5, 7, 9, 11];
    var naturalMinor = [0, 2, 3, 5, 7, 8, 10];
    var intervals = key.mode === 'minor' ? naturalMinor : major;
    for (var i = 0; i < intervals.length; i++) {
      if (intervals[i] === diff) return i + 1;
    }
    return null;
  }

  var ROMAN_MAJOR = ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii'];
  var ROMAN_MINOR = ['i', 'ii', 'III', 'iv', 'v', 'VI', 'VII'];

  function romanNumeralSimple(degree, keyMode, chordId) {
    if (!degree) return '—';
    var base = keyMode === 'minor' ? ROMAN_MINOR[degree - 1] : ROMAN_MAJOR[degree - 1];
    if (!base) return '—';
    var def = CK.get(chordId);
    if (!def) return base;
    var sym = def.symbol || '';
    if (sym === 'dim' || sym === 'o') return base + '°';
    if (sym === 'dim7') return base + '°7';
    if (sym === 'min7b5' || sym === 'm7♭5' || sym.indexOf('m7♭5') === 0) return base + 'ø7';
    if (sym === '' || sym === 'maj') return base;
    if (sym.indexOf('maj7') === 0) return base + 'maj7';
    if (sym.indexOf('m') === 0 || sym === 'min7' || sym === 'm7') {
      var rest = sym.replace(/^m(in)?/, '') || '7';
      if (rest === '7' || rest === '9' || rest === '11' || rest === '13') return base + rest;
      return base + (sym === 'm' ? '' : sym.replace(/^m/, ''));
    }
    if (/^[79]|^1[13]/.test(sym) || sym === '7' || sym === '9' || sym === '11' || sym === '13') {
      return base + sym;
    }
    if (sym.indexOf('sus') >= 0) return base + '(sus)';
    return base + sym;
  }

  function normalizeRawSegment(raw, index) {
    if (!raw || typeof raw !== 'object') return null;
    var t0 = raw.t0;
    var t1 = raw.t1;
    if (t0 == null && raw.start != null) t0 = raw.start;
    if (t1 == null && raw.end != null) t1 = raw.end;
    if (t0 == null && Array.isArray(raw.time) && raw.time.length >= 2) {
      t0 = raw.time[0];
      t1 = raw.time[1];
    }
    if (t0 == null || t1 == null) {
      return { _bad: true, index: index, reason: 'missing t0/t1 or start/end' };
    }
    var symbol = raw.symbol || raw.chord || raw.label || raw.name || '';
    return { t0: Number(t0), t1: Number(t1), symbol: String(symbol), raw: raw };
  }

  function mergeAdjacentSame(segments) {
    if (!segments.length) return [];
    var out = [];
    var cur = Object.assign({}, segments[0]);
    for (var i = 1; i < segments.length; i++) {
      var s = segments[i];
      if (s.symbol === cur.symbol && Math.abs(s.t0 - cur.t1) < 1e-6) {
        cur.t1 = s.t1;
      } else {
        out.push(cur);
        cur = Object.assign({}, s);
      }
    }
    out.push(cur);
    return out;
  }

  function enrichSegment(seg, key, options) {
    options = options || {};
    var preferFlats = options.preferFlats != null ? options.preferFlats : /b/.test(key.rootStr);
    var parsed = parseChordLabel(seg.symbol);
    var res = resolveChordId(parsed);
    var chordRootPc = parsed ? CK.parseRoot(parsed.rootStr) : null;
    var degree = chordRootPc != null ? degreeInKey(chordRootPc, key) : null;
    var roman = romanNumeralSimple(degree, key.mode, res.chordId);
    var display = seg.symbol;
    if (parsed && res.chordId) {
      var rlab = CK.rootLabel(chordRootPc, preferFlats);
      var defSym = CK.get(res.chordId).symbol || '';
      display = rlab + defSym;
    }
    var spell =
      parsed && res.chordId
        ? CK.notes(parsed.rootStr, res.chordId, { preferFlats: preferFlats })
        : null;
    var midi =
      parsed && res.chordId
        ? CK.midiVoicing(parsed.rootStr, res.chordId, options.voicingOctave == null ? 4 : options.voicingOctave)
        : [];

    return {
      t0: seg.t0,
      t1: seg.t1,
      duration: seg.t1 - seg.t0,
      symbol: seg.symbol,
      displaySymbol: display,
      rootStr: parsed ? parsed.rootStr : null,
      bassStr: parsed ? parsed.bassStr : null,
      chordId: res.chordId,
      chordKit: res.chordId ? CK.get(res.chordId) : null,
      degree: degree,
      diatonic: degree != null,
      roman: roman,
      notes: spell ? spell.notes : null,
      midiClose: spell ? spell.midi : null,
      midiVoicing: midi,
      warning: res.warning,
      slash: parsed && parsed.bassStr ? parsed.bassStr + ' in bass' : null
    };
  }

  /**
   * Main entry: pass output from your audio pipeline; get sorted timeline + bar grid + Roman summary.
   *
   * @param {object} input — { key, chords|segments|timeline, tempoBpm?, timeSignature? }
   * @param {object} options — { mergeDuplicates, preferFlats, voicingOctave, quantizeBars }
   */
  function arrangeFromAnalysis(input, options) {
    options = options || {};
    var warnings = [];
    var key = normalizeKey(input.key != null ? input.key : input);

    var rawList = input.chords || input.segments || input.timeline || input.detections || [];
    if (!Array.isArray(rawList)) {
      warnings.push('chord list was not an array; expected chords / segments / timeline');
      rawList = [];
    }

    var normalized = [];
    for (var i = 0; i < rawList.length; i++) {
      var n = normalizeRawSegment(rawList[i], i);
      if (n && n._bad) {
        warnings.push('segment ' + i + ': ' + n.reason);
        continue;
      }
      if (n) normalized.push(n);
    }

    normalized.sort(function (a, b) {
      return a.t0 - b.t0;
    });

    if (options.mergeDuplicates !== false) {
      normalized = mergeAdjacentSame(normalized);
    }

    var enriched = normalized.map(function (seg) {
      return enrichSegment(seg, key, options);
    });

    enriched.forEach(function (e) {
      if (e.warning) warnings.push(e.symbol + ': ' + e.warning);
      if (e.degree == null && e.chordId) warnings.push(e.displaySymbol + ': not diatonic in ' + key.rootStr + ' ' + key.mode);
    });

    var bpm = input.tempoBpm != null ? Number(input.tempoBpm) : options.tempoBpm != null ? Number(options.tempoBpm) : null;
    var ts = input.timeSignature || options.timeSignature || [4, 4];
    var beatsPerBar = ts[0] || 4;

    var grid = null;
    if (bpm && bpm > 0) {
      grid = buildMeasureGrid(enriched, bpm, beatsPerBar, options);
    }

    var romanLine = enriched
      .map(function (e) {
        return e.roman;
      })
      .join(' | ');

    return {
      key: key,
      tempoBpm: bpm,
      timeSignature: ts,
      segments: enriched,
      measureGrid: grid,
      romanLine: romanLine,
      warnings: warnings,
      examplePayload: EXAMPLE_PAYLOAD
    };
  }

  function findSegmentAt(segments, t) {
    for (var i = 0; i < segments.length; i++) {
      var s = segments[i];
      if (t >= s.t0 && t < s.t1) return s;
    }
    for (var j = segments.length - 1; j >= 0; j--) {
      var s2 = segments[j];
      if (t >= s2.t0) return s2;
    }
    return segments[0] || null;
  }

  /**
   * One cell per bar: chord active near bar start (25% into bar).
   */
  function buildMeasureGrid(segments, bpm, beatsPerBar, options) {
    options = options || {};
    var secPerBeat = 60 / bpm;
    var barSec = secPerBeat * beatsPerBar;
    var endT = 0;
    for (var i = 0; i < segments.length; i++) {
      if (segments[i].t1 > endT) endT = segments[i].t1;
    }
    var nBars = Math.max(1, Math.ceil(endT / barSec));
    var rows = [];
    for (var b = 0; b < nBars; b++) {
      var tProbe = b * barSec + barSec * (options.gridProbe || 0.25);
      var hit = findSegmentAt(segments, tProbe);
      rows.push({
        bar: b + 1,
        t0: b * barSec,
        t1: (b + 1) * barSec,
        segment: hit,
        displaySymbol: hit ? hit.displaySymbol : '—',
        roman: hit ? hit.roman : '—',
        chordId: hit ? hit.chordId : null
      });
    }
    return { barDurationSec: barSec, beatsPerBar: beatsPerBar, rows: rows };
  }

  /** Hook: when your key detector finishes, call this then re-run arrange with new key. */
  function onKeyDetected(keyPayload) {
    return normalizeKey(keyPayload);
  }

  var AudioChordArranger = {
    EXAMPLE_PAYLOAD: EXAMPLE_PAYLOAD,
    normalizeKey: normalizeKey,
    parseChordLabel: parseChordLabel,
    qualityToChordId: qualityToChordId,
    arrangeFromAnalysis: arrangeFromAnalysis,
    mergeAdjacentSame: mergeAdjacentSame,
    buildMeasureGrid: buildMeasureGrid,
    enrichSegment: enrichSegment,
    onKeyDetected: onKeyDetected,
    degreeInKey: degreeInKey
  };

  global.AudioChordArranger = AudioChordArranger;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = AudioChordArranger;
  }
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : this);
