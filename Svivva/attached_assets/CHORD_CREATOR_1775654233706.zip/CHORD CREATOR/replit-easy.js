/**
 * ReplitChord — one entry point for Replit: pass whatever your audio step produced.
 *
 * Load after chord-generator.js + analysis-bridge.js:
 *   <script src="chord-generator.js"></script>
 *   <script src="analysis-bridge.js"></script>
 *   <script src="replit-easy.js"></script>
 *
 *   var out = ReplitChord.go(yourAnalyzerOutput);
 *
 * Node:
 *   require('./chord-generator.js');
 *   require('./analysis-bridge.js');
 *   const ReplitChord = require('./replit-easy.js');
 */
(function (global) {
  'use strict';

  var A = global.AudioChordArranger;
  if (!A) {
    throw new Error('Load chord-generator.js then analysis-bridge.js before replit-easy.js');
  }

  function pickChordArray(obj) {
    if (Array.isArray(obj)) return obj;
    var keys = ['chords', 'segments', 'timeline', 'detections', 'progression', 'harmony', 'events', 'items', 'changes'];
    for (var k = 0; k < keys.length; k++) {
      if (Array.isArray(obj[keys[k]])) return obj[keys[k]];
    }
    if (obj.analysis && Array.isArray(obj.analysis.chords)) return obj.analysis.chords;
    if (obj.result && Array.isArray(obj.result.chords)) return obj.result.chords;
    if (obj.audio && Array.isArray(obj.audio.chords)) return obj.audio.chords;
    if (obj.track && Array.isArray(obj.track.chords)) return obj.track.chords;
    return [];
  }

  function pickKey(obj) {
    if (obj == null) return { root: 'C', mode: 'major' };
    if (typeof obj.key === 'string') return obj.key;
    if (obj.key != null && typeof obj.key === 'object') return obj.key;
    var alt =
      obj.detectedKey ||
      obj.estimatedKey ||
      obj.keyEstimate ||
      obj.key_signature ||
      obj.keySignature ||
      obj.tonality;
    if (typeof alt === 'string') return alt;
    if (alt != null && typeof alt === 'object') return alt;
    if (obj.tonic != null && obj.mode != null) return { root: obj.tonic, mode: obj.mode };
    if (obj.keyRoot != null && obj.keyMode != null) return { root: obj.keyRoot, mode: obj.keyMode };
    return { root: 'C', mode: 'major' };
  }

  function pickBpm(obj) {
    var b =
      obj.tempoBpm != null
        ? obj.tempoBpm
        : obj.bpm != null
          ? obj.bpm
          : obj.tempo != null
            ? obj.tempo
            : obj.detectedBpm != null
              ? obj.detectedBpm
              : obj.estimatedBpm != null
                ? obj.estimatedBpm
                : obj.beatsPerMinute != null
                  ? obj.beatsPerMinute
                  : null;
    if (b != null && Number(b) > 0) return Number(b);
    return null;
  }

  function pickTimeSignature(obj) {
    var ts = obj.timeSignature || obj.ts || obj.meter || obj.time_sig;
    if (Array.isArray(ts) && ts.length >= 2) return [ts[0], ts[1]];
    if (typeof ts === 'string' && ts.indexOf('/') >= 0) {
      var p = ts.split('/');
      return [parseInt(p[0], 10) || 4, parseInt(p[1], 10) || 4];
    }
    return [4, 4];
  }

  /**
   * Milliseconds → seconds only when explicitly requested (auto-guess is unsafe for long tracks).
   */
  function shouldTreatAsMs(list, obj, options) {
    if (options && options.timesInSeconds === true) return false;
    if (options && options.timesInMilliseconds === true) return true;
    if (obj && (obj.durationUnit === 'ms' || obj.timeUnit === 'ms' || obj.timeUnit === 'milliseconds')) {
      return true;
    }
    return false;
  }

  function coerceSegment(raw, timeScale) {
    timeScale = timeScale || 1;
    var t0 =
      raw.t0 != null
        ? raw.t0
        : raw.start != null
          ? raw.start
          : raw.from != null
            ? raw.from
            : raw.begin != null
              ? raw.begin
              : Array.isArray(raw.time)
                ? raw.time[0]
                : raw.msStart != null
                  ? raw.msStart
                  : null;
    var t1 =
      raw.t1 != null
        ? raw.t1
        : raw.end != null
          ? raw.end
          : raw.to != null
            ? raw.to
            : raw.until != null
              ? raw.until
              : Array.isArray(raw.time)
                ? raw.time[1]
                : raw.msEnd != null
                  ? raw.msEnd
                  : null;
    var sym =
      raw.symbol != null
        ? raw.symbol
        : raw.chord != null
          ? raw.chord
          : raw.label != null
            ? raw.label
            : raw.name != null
              ? raw.name
              : raw.ch != null
                ? raw.ch
                : raw.value != null
                  ? raw.value
                  : '';
    return {
      t0: t0 != null ? Number(t0) * timeScale : null,
      t1: t1 != null ? Number(t1) * timeScale : null,
      symbol: String(sym)
    };
  }

  /** String-only progression → fake timings (1 second per chord). */
  function stringListToSegments(arr) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      out.push({ t0: i, t1: i + 1, symbol: String(arr[i]) });
    }
    return out;
  }

  /**
   * Turn almost anything into { key, tempoBpm, timeSignature, chords } for AudioChordArranger.
   */
  function toPayload(obj, options) {
    options = options || {};
    var list = pickChordArray(obj);
    if (!list.length && typeof obj === 'object' && obj != null && typeof obj.chord === 'string') {
      list = [{ t0: 0, t1: 1, symbol: obj.chord }];
    }
    if (list.length && typeof list[0] === 'string') {
      list = stringListToSegments(list);
    }
    var asMs = shouldTreatAsMs(list, obj, options);
    var scale = asMs ? 0.001 : 1;
    var chords = [];
    for (var i = 0; i < list.length; i++) {
      var c = coerceSegment(list[i], scale);
      if (c.symbol && c.t0 != null && c.t1 != null) {
        chords.push({ t0: c.t0, t1: c.t1, symbol: c.symbol });
      }
    }
    return {
      key: pickKey(obj),
      tempoBpm: pickBpm(obj),
      timeSignature: pickTimeSignature(obj),
      chords: chords,
      _meta: { assumedMilliseconds: asMs, segmentCount: chords.length }
    };
  }

  /**
   * Single call: pass analyzer object, JSON string, or chord name array.
   * @returns {object} Easy fields + _full (full arrangeFromAnalysis) or { ok:false, error }
   */
  function go(input, options) {
    options = options || {};
    var obj = input;
    if (typeof input === 'string') {
      try {
        obj = JSON.parse(input);
      } catch (e) {
        return { ok: false, error: 'Could not parse JSON: ' + (e.message || String(e)) };
      }
    }
    if (Array.isArray(input) && (input.length === 0 || typeof input[0] === 'string')) {
      obj = { chords: stringListToSegments(input), key: options.key || { root: 'C', mode: 'major' }, tempoBpm: options.tempoBpm };
    }
    if (obj == null || typeof obj !== 'object') {
      return { ok: false, error: 'Expected an object, JSON string, or string[] of chord names' };
    }

    var payload = toPayload(obj, options);
    if (!payload.chords.length) {
      return {
        ok: false,
        error: 'No timed chords found. Put them in chords[], segments[], timeline[], or pass ["Cm7","F7"]',
        hint: 'Each item needs a symbol/chord/label and start/end (or t0/t1, or time:[a,b])',
        sample: A.EXAMPLE_PAYLOAD
      };
    }

    var result = A.arrangeFromAnalysis(payload, options);

    var timeline = result.segments.map(function (s) {
      return {
        start: s.t0,
        end: s.t1,
        chord: s.displaySymbol,
        roman: s.roman,
        id: s.chordId,
        midi: s.midiVoicing,
        notes: s.notes
      };
    });

    var bars = null;
    if (result.measureGrid && result.measureGrid.rows) {
      bars = result.measureGrid.rows.map(function (r) {
        return { bar: r.bar, chord: r.displaySymbol, roman: r.roman, startSec: r.t0, endSec: r.t1 };
      });
    }

    var keyLabel = result.key.rootStr + ' ' + result.key.mode;

    return {
      ok: true,
      key: keyLabel,
      bpm: result.tempoBpm,
      romanLine: result.romanLine,
      timeline: timeline,
      bars: bars,
      warnings: result.warnings,
      assumedMilliseconds: payload._meta.assumedMilliseconds,
      _full: result
    };
  }

  var ReplitChord = {
    go: go,
    toPayload: toPayload,
    HELP:
      'ReplitChord.go(analyzerOutput) — pass any object with chords/segments/timeline, optional key/bpm. ' +
      'Or go(["Am7","D7","Gmaj7"], { key: { root: "G", mode: "major" }, tempoBpm: 120 }).'
  };

  global.ReplitChord = ReplitChord;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = ReplitChord;
  }
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : this);
