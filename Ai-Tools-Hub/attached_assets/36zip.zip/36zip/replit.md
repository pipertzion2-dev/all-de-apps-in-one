# Idea Scoring & Feasibility Tool

A static web-based tool for scoring and assessing the feasibility of concepts, product ideas, or team scenarios. Built as a standalone engineering-as-marketing tool for the Svivva platform.

## Tech Stack
- HTML5, CSS3, Vanilla JavaScript (ES6)
- No build step or backend required
- Custom font: `zc-regular.ttf`
- Deployed as a static site

## Project Structure
- `36/index.html` — Main entry point (SEO-optimized with structured data, Open Graph, meta tags)
- `36/app.js` — Core logic (scoring, artifact rendering, form handling)
- `36/styles.css` — Dark-themed UI with responsive three-panel grid layout
- `36/zc-regular.ttf` — Custom font file

## SEO Features
- Title: "Free Idea Scoring & Feasibility Tool Online | Svivva"
- Canonical URL: https://svivva.com/tools/idea-scoring
- JSON-LD structured data (WebApplication + FAQPage schemas)
- Open Graph and Twitter Card meta tags
- 540-word SEO content article below the tool
- 5 FAQ entries with schema markup
- Internal links to svivva.com throughout
- Breadcrumb navigation (Svivva / Idea Scoring Tool)

## Running
- Dev: `npx serve 36 -l 5000 --no-clipboard` on port 5000
- Deploy: Static site from `36/` directory
