# Team Permission Simulator — Svivva

## Overview
A free online tool by Svivva that simulates team permissions and collaboration flows. Users input a team scenario and category, and the app generates a permission map with roles and access levels. Optimized for Google search as an engineering-as-marketing tool to drive traffic to svivva.com.

## Tech Stack
- Vanilla HTML5, CSS3, JavaScript (no build step, no framework)
- Custom font: `zc-regular.ttf`
- Static site deployment (publicDir: `39`)

## Project Structure
```
39/
├── index.html      # Main entry point, SEO-optimized with structured data
├── app.js          # Simulation logic (IIFE), role derivation, SVG rendering
├── styles.css      # Dark theme, CSS Grid layout, responsive breakpoints
└── zc-regular.ttf  # Custom monospace font
```

## Running
```
python3 -m http.server 5000 --directory 39
```
Workflow configured as "Start application" on port 5000 (webview).
Deployment configured as static site with `publicDir: "39"`.

## SEO / Engineering as Marketing
- Title: "Free Team Permission Simulator Online — Role & Access Map Generator | Svivva"
- H1: "Free Team Permission Simulator Online"
- Meta description: 155 chars, keyword-rich
- Schema.org structured data: WebApplication + FAQPage
- Open Graph and Twitter Card meta tags
- Canonical URL: https://svivva.com/tools/team-permission-simulator
- 400-600 word SEO content section in footer
- Internal links throughout pointing to svivva.com
- 5 FAQ entries with structured data markup
- Footer nav with links to svivva.com, /projects, /pricing

## Features
- Six mode categories: Hardware, Play, Idea, Team, Marketplace, Build
- Permission map generation with role-based access (View/Edit/Share)
- Confidence/readiness scoring based on input detail
- SVG flow graph rendering
- Responsive layout (3-panel → 2-panel → 1-panel)
- Analytics hooks for Google Analytics and Segment (if present)
