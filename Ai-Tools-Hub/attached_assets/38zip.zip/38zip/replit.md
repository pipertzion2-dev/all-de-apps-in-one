# API Marketplace Listing Generator

A static frontend tool for Svivva that generates production-style API marketplace listing previews from user-provided concepts. Optimized for Google search as an engineering-as-marketing asset.

## Project Structure

```
38/
  index.html      - Main entry point and UI (SEO-optimized)
  app.js          - Application logic (form handling, preview generation)
  styles.css      - Styling with CSS variables, grid layout, dark theme
  zc-regular.ttf  - Custom monospace font
```

## How to Run

Static site served via Python's built-in HTTP server:

```
python3 -m http.server 5000 --directory 38
```

## Deployment

Configured as a static site deployment with `publicDir: 38`.

## Tech Stack

- Vanilla HTML5, CSS3, JavaScript (ES6)
- No external dependencies or build step
- Custom font via @font-face
- Three-panel CSS Grid layout with responsive breakpoints

## SEO Features

- H1 keyword: "API Marketplace Listing Generator"
- Meta description optimized for search
- Open Graph and Twitter Card meta tags
- JSON-LD structured data (WebApplication + FAQPage schemas)
- Canonical URL set to svivva.com/tools/api-marketplace-listing-generator
- 510-word SEO content section below the fold
- Internal linking throughout to svivva.com (marketplace, tools, docs)
- Multiple CTAs: inline, below-preview, sticky bar, and in-content
- 5 FAQ items with structured data markup
- Footer navigation with cross-domain internal links
