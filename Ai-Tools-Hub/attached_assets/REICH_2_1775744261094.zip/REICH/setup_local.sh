#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/pip install --upgrade pip -q
.venv/bin/pip install -r requirements.txt
echo "Setup done. Test with:"
echo "  .venv/bin/python demo.py"
echo "Web UI on port 8765:  ./run_localhost_8765.sh  →  http://localhost:8765/"
echo "  (or: .venv/bin/python web_app.py — may use 8766 if 8765 is busy)"
echo "MIDI files appear in ./midi_out/ when using demo.py"
