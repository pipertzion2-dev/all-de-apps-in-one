"""
Replit-friendly entry: call from your app after audio key/tempo analysis.

Example::

    from replit_entry import compose_from_detection

    result = compose_from_detection(
        duration_sec=track_duration,
        bpm=detected_bpm,
        detected_mode="minor",  # from your key detector
        key_root="A",
        user_scale_name="dorian",
        out_dir="/tmp/midi_out",
    )
    # result["counterpoint_paths"] -> 3 .mid files
    # result["hocket_paths"] -> 6 .mid files
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

from reich_composer import (
    register_user_scale,
    run_from_audio_params,
    scale_matches_detection,
)
from reich_composer.composer import StyleName


def load_user_scales_json(path: str | Path) -> None:
    """
    JSON format: { "scale_name": { "intervals": [0,2,3,5,7,9,10], "tonality": "minor" } }
    tonality: "major" | "minor" | "both"
    """
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    for name, spec in data.items():
        intervals = tuple(spec["intervals"])
        ton: Any = spec.get("tonality", "both")
        register_user_scale(name, intervals, ton)


def compose_from_detection(
    *,
    duration_sec: float,
    bpm: float,
    detected_mode: Literal["major", "minor"],
    key_root: str,
    out_dir: str,
    user_scale_name: str | None = None,
    user_pitch_classes: list[int] | None = None,
    forced_user_tonality: Literal["major", "minor", "both"] | None = None,
    override_scale: bool = False,
    counterpoint_style: StyleName = "reich_electric",
    hocket_style: StyleName = "reich_electric",
    seed: int | None = None,
) -> dict[str, Any]:
    return run_from_audio_params(
        duration_sec=duration_sec,
        bpm=bpm,
        detected_mode=detected_mode,
        key_root=key_root,
        out_dir=out_dir,
        user_scale_name=user_scale_name,
        user_pitch_classes=user_pitch_classes,
        forced_user_tonality=forced_user_tonality,
        override_scale=override_scale,
        counterpoint_style=counterpoint_style,
        hocket_style=hocket_style,
        seed=seed,
    )


def check_scale_for_key(scale_name: str, detected_mode: Literal["major", "minor"]) -> dict[str, Any]:
    """UI helper: whether the user's scale fits the detected mode without override."""
    ok = scale_matches_detection(scale_name, detected_mode)
    return {"scale": scale_name, "detected_mode": detected_mode, "compatible": ok, "needs_override": not ok}
