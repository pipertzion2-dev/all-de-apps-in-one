#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "=========================================="
echo "  Reich composer — starting web server"
echo "=========================================="
echo ""
if [ ! -f ".venv/bin/python" ]; then
  echo "Creating Python environment (first time only)..."
  python3 -m venv .venv
  .venv/bin/pip install -q -r requirements.txt
fi
export PORT=8765
export OPEN_BROWSER=1
echo "When you see 'Serving on', open in your browser:"
echo ""
echo "    http://127.0.0.1:8765/"
echo ""
echo "If the page does not load, try: http://localhost:8765/"
echo "Keep this window open. Press Ctrl+C to stop."
echo ""
.venv/bin/python web_app.py
echo ""
read -r -p "Press Enter to close..."
