"""
Look up scale intervals from the network: optional remote JSON catalog and/or an LLM API.

Configure with environment variables (e.g. Replit Secrets):

  SCALE_LOOKUP_ONLINE=1
  OPENAI_API_KEY=sk-...           # or SCALE_LOOKUP_API_KEY
  OPENAI_BASE_URL=https://api.openai.com/v1   # OpenRouter, Groq, etc. also work
  SCALE_LOOKUP_MODEL=gpt-4o-mini

  SCALE_CATALOG_URL=https://example.com/scales.json   # optional

Catalog JSON (either shape):

  {"scales": {"name_with_underscores": {"intervals": [0,2,4,5,7,9,11], "tonality": "major"}}}
  {"pelog": [0, 1, 3, 7, 8]}
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from typing import Any

_CATALOG_CACHE: tuple[float, dict[str, Any]] | None = None
_CATALOG_TTL_SEC = 300.0


def is_online_lookup_enabled() -> bool:
    return os.environ.get("SCALE_LOOKUP_ONLINE", "").strip().lower() in ("1", "true", "yes", "on")


def lookup_status() -> dict[str, Any]:
    """Safe to expose in the UI — no secrets."""
    key = bool(
        (os.environ.get("OPENAI_API_KEY") or os.environ.get("SCALE_LOOKUP_API_KEY") or "").strip()
    )
    return {
        "online_enabled": is_online_lookup_enabled(),
        "has_llm_key": key,
        "has_catalog_url": bool((os.environ.get("SCALE_CATALOG_URL") or "").strip()),
        "base_url_host": _parse_host(os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")),
        "model": (os.environ.get("SCALE_LOOKUP_MODEL") or "gpt-4o-mini").strip(),
    }


def _parse_host(url: str) -> str:
    try:
        from urllib.parse import urlparse

        return urlparse(url).netloc or url
    except Exception:
        return "—"


def offline_lookup_hint() -> str:
    if is_online_lookup_enabled():
        if not (os.environ.get("OPENAI_API_KEY") or os.environ.get("SCALE_LOOKUP_API_KEY")):
            return "Online lookup is on but no API key set — add OPENAI_API_KEY (or SCALE_LOOKUP_API_KEY)."
        return ""
    return (
        "Tip: set SCALE_LOOKUP_ONLINE=1 and OPENAI_API_KEY to resolve unknown scale names via an LLM, "
        "or SCALE_CATALOG_URL for your own JSON scale database."
    )


def _normalize_key(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[\s\-]+", "_", s)
    return re.sub(r"_+", "_", s).strip("_")


def _fetch_json_url(url: str, timeout: float = 20.0) -> Any:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "reich-composer-scale-lookup/1.0"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _load_catalog() -> dict[str, Any] | None:
    global _CATALOG_CACHE
    url = (os.environ.get("SCALE_CATALOG_URL") or "").strip()
    if not url:
        return None
    now = time.monotonic()
    if _CATALOG_CACHE is not None and now - _CATALOG_CACHE[0] < _CATALOG_TTL_SEC:
        return _CATALOG_CACHE[1]
    data = _fetch_json_url(url)
    _CATALOG_CACHE = (now, data)
    return data


def _intervals_from_catalog_value(v: Any) -> tuple[int, ...] | None:
    if isinstance(v, list):
        nums = [int(x) % 12 for x in v]
    elif isinstance(v, dict) and "intervals" in v:
        nums = [int(x) % 12 for x in v["intervals"]]
    else:
        return None
    if len(nums) < 2:
        return None
    return tuple(sorted(set(nums)))


def lookup_catalog(query: str) -> tuple[int, ...] | None:
    if not is_online_lookup_enabled():
        return None
    try:
        data = _load_catalog()
    except (OSError, urllib.error.URLError, ValueError, json.JSONDecodeError):
        return None
    if not data:
        return None
    qn = _normalize_key(query)
    scales = data.get("scales", data)
    if not isinstance(scales, dict):
        return None
    for k, v in scales.items():
        if _normalize_key(str(k)) == qn:
            return _intervals_from_catalog_value(v)
    fuzzy: list[tuple[int, ...]] = []
    for k, v in scales.items():
        kn = _normalize_key(str(k))
        if qn in kn or kn in qn:
            got = _intervals_from_catalog_value(v)
            if got:
                fuzzy.append(got)
    if len(fuzzy) == 1:
        return fuzzy[0]
    return None


def lookup_llm(query: str) -> tuple[int, ...] | None:
    if not is_online_lookup_enabled():
        return None
    key = (os.environ.get("OPENAI_API_KEY") or os.environ.get("SCALE_LOOKUP_API_KEY") or "").strip()
    if not key:
        return None
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    model = (os.environ.get("SCALE_LOOKUP_MODEL") or "gpt-4o-mini").strip()
    url = f"{base}/chat/completions"
    system = (
        "You output only valid JSON, no markdown. Given a musical scale or raga name, respond with "
        '{"intervals":[...],"tonality_hint":"major|minor|both"} where intervals are integers 0-11 '
        "semitones above the root within one octave, sorted, unique, at least 3 notes. "
        "Use common 12-TET Western or Indian raga approximations. If unknown, use intervals []."
    )
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f'Scale name or query: "{query}"'},
        ],
        "temperature": 0.2,
        "max_tokens": 256,
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
            "User-Agent": "reich-composer-scale-lookup/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=45.0) as resp:
            out = json.loads(resp.read().decode("utf-8"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError):
        return None
    try:
        text = out["choices"][0]["message"]["content"].strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        parsed = json.loads(text)
        nums = parsed.get("intervals") or []
        nums = [int(x) % 12 for x in nums]
        if len(nums) < 2:
            return None
        return tuple(sorted(set(nums)))
    except (KeyError, ValueError, TypeError, IndexError):
        return None


def lookup_scale_intervals_online(query: str) -> tuple[int, ...] | None:
    """
    Try remote catalog (if configured), then LLM. Returns None if disabled or both fail.
    """
    q = query.strip()
    if not q:
        return None
    cat = lookup_catalog(q)
    if cat is not None:
        return cat
    return lookup_llm(q)
