"""
Scale database: tonality (major/minor family) vs detected key from audio.
Refuses mismatched scales unless override=True.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Literal

Mode = Literal["major", "minor"]

# Pitch classes 0-11 from C
_SCALE_DEFS: dict[str, tuple[int, ...]] = {
    "major": (0, 2, 4, 5, 7, 9, 11),
    "ionian": (0, 2, 4, 5, 7, 9, 11),
    "minor": (0, 2, 3, 5, 7, 8, 10),
    "natural_minor": (0, 2, 3, 5, 7, 8, 10),
    "aeolian": (0, 2, 3, 5, 7, 8, 10),
    "dorian": (0, 2, 3, 5, 7, 9, 10),
    "phrygian": (0, 1, 3, 5, 7, 8, 10),
    "lydian": (0, 2, 4, 6, 7, 9, 11),
    "mixolydian": (0, 2, 4, 5, 7, 9, 10),
    "locrian": (0, 1, 3, 5, 6, 8, 10),
    "harmonic_minor": (0, 2, 3, 5, 7, 8, 11),
    "melodic_minor_asc": (0, 2, 3, 5, 7, 9, 11),
    "pentatonic_major": (0, 2, 4, 7, 9),
    "pentatonic_minor": (0, 3, 5, 7, 10),
    "blues_minor": (0, 3, 5, 6, 7, 10),
    "whole_tone": (0, 2, 4, 6, 8, 10),
    "diminished_whole_half": (0, 2, 3, 5, 6, 8, 9, 11),
}

# Indian classical — pitch classes from Sa in 12-TET (shuddha/komal approximations).
# Useful for sketching; not a substitute for shruti / raga grammar in performance.
_INDIAN_SCALE_DEFS: dict[str, tuple[int, ...]] = {
    # Hindustani (thaat / common raga skeletons)
    "raga_bilawal": (0, 2, 4, 5, 7, 9, 11),
    "raga_yaman": (0, 2, 4, 6, 7, 9, 11),
    "raga_khamaj": (0, 2, 4, 5, 7, 9, 10),
    "raga_kafi": (0, 2, 3, 5, 7, 9, 10),
    "raga_asavari": (0, 2, 3, 5, 7, 8, 10),
    "raga_bhairav": (0, 1, 4, 5, 7, 8, 11),
    "raga_bhairavi": (0, 1, 3, 5, 7, 8, 10),
    "raga_marwa": (0, 1, 4, 6, 7, 9, 11),
    "raga_purvi": (0, 1, 4, 6, 7, 8, 11),
    "raga_todi": (0, 1, 3, 6, 7, 8, 10),
    "raga_malkauns": (0, 3, 5, 8, 10),
    "raga_darbari_kanada": (0, 2, 3, 5, 7, 9, 10),
    "raga_shivaranjani": (0, 2, 3, 7, 9),
    "raga_bageshri": (0, 2, 3, 5, 7, 9, 10),
    "raga_abhogi": (0, 2, 3, 5, 7),
    # Carnatic melakarta–style sets (same 12-TET abstraction)
    "carnatic_shankarabharanam": (0, 2, 4, 5, 7, 9, 11),
    "carnatic_kharaharapriya": (0, 2, 3, 5, 7, 9, 10),
    "carnatic_harikambhoji": (0, 2, 4, 5, 7, 9, 10),
    "carnatic_natabhairavi": (0, 2, 3, 5, 7, 8, 10),
    "carnatic_mayamalavagowla": (0, 1, 4, 5, 7, 8, 11),
    "carnatic_charukesi": (0, 2, 4, 5, 7, 8, 10),
}

_INDIAN_SCALE_TONALITY: dict[str, Mode | Literal["both"]] = {
    "raga_bilawal": "major",
    "raga_yaman": "major",
    "raga_khamaj": "major",
    "raga_kafi": "minor",
    "raga_asavari": "minor",
    "raga_bhairav": "minor",
    "raga_bhairavi": "minor",
    "raga_marwa": "minor",
    "raga_purvi": "minor",
    "raga_todi": "minor",
    "raga_malkauns": "both",
    "raga_darbari_kanada": "minor",
    "raga_shivaranjani": "both",
    "raga_bageshri": "minor",
    "raga_abhogi": "both",
    "carnatic_shankarabharanam": "major",
    "carnatic_kharaharapriya": "minor",
    "carnatic_harikambhoji": "major",
    "carnatic_natabhairavi": "minor",
    "carnatic_mayamalavagowla": "minor",
    "carnatic_charukesi": "minor",
}

_SCALE_DEFS.update(_INDIAN_SCALE_DEFS)

# Chinese / Arabic / Japanese / etc. — 12-TET sketches for composition, not ethnomusicology claims.
_WORLD_SCALE_DEFS: dict[str, tuple[int, ...]] = {
    "chinese_gong": (0, 2, 4, 7, 9),
    "chinese_shang": (0, 2, 5, 7, 10),
    "chinese_jue": (0, 3, 5, 8, 10),
    "chinese_zhi": (0, 2, 5, 7, 9),
    "chinese_yu": (0, 3, 5, 7, 10),
    "japanese_in": (0, 1, 5, 7, 8),
    "japanese_yo": (0, 2, 5, 7, 9),
    "korean_minyo": (0, 3, 5, 7, 9),
    "arabic_hijaz": (0, 1, 4, 5, 7, 8, 11),
    "arabic_hijazkar": (0, 1, 4, 5, 7, 8, 10),
    "arabic_rast": (0, 2, 4, 5, 7, 9, 10),
    "arabic_nahawand": (0, 2, 3, 5, 7, 8, 10),
    "arabic_saba": (0, 1, 3, 4, 5, 8, 10),
    "arabic_kurd": (0, 2, 3, 5, 7, 8, 10),
    "turkish_hicaz": (0, 1, 4, 5, 7, 8, 11),
    "turkish_rast": (0, 2, 4, 5, 7, 9, 10),
    "turkish_kurdi": (0, 2, 3, 5, 7, 8, 10),
    "ethiopian_ambassel": (0, 2, 4, 7, 9),
    "ethiopian_tizita": (0, 2, 3, 5, 7, 8, 10),
}

_WORLD_TONALITY: dict[str, Mode | Literal["both"]] = {
    "chinese_gong": "both",
    "chinese_shang": "both",
    "chinese_jue": "both",
    "chinese_zhi": "both",
    "chinese_yu": "both",
    "japanese_in": "both",
    "japanese_yo": "both",
    "korean_minyo": "both",
    "arabic_hijaz": "minor",
    "arabic_hijazkar": "minor",
    "arabic_rast": "major",
    "arabic_nahawand": "minor",
    "arabic_saba": "minor",
    "arabic_kurd": "minor",
    "turkish_hicaz": "minor",
    "turkish_rast": "major",
    "turkish_kurdi": "minor",
    "ethiopian_ambassel": "both",
    "ethiopian_tizita": "minor",
}

_SCALE_DEFS.update(_WORLD_SCALE_DEFS)

# Which tonal family each named scale belongs to for *matching* detected audio mode.
# "both" = allowed with either major or minor detection (pentatonic/blues often ambiguous in practice;
# we still tag conservatively).
_SCALE_TONALITY: dict[str, Mode | Literal["both"]] = {
    "major": "major",
    "ionian": "major",
    "lydian": "major",
    "mixolydian": "major",
    "pentatonic_major": "major",
    "minor": "minor",
    "natural_minor": "minor",
    "aeolian": "minor",
    "dorian": "minor",
    "phrygian": "minor",
    "harmonic_minor": "minor",
    "melodic_minor_asc": "minor",
    "pentatonic_minor": "minor",
    "blues_minor": "minor",
    "locrian": "minor",
    "whole_tone": "both",
    "diminished_whole_half": "both",
}
_SCALE_TONALITY.update(_INDIAN_SCALE_TONALITY)
_SCALE_TONALITY.update(_WORLD_TONALITY)


def register_user_scale(
    name: str,
    pitch_classes_from_root: tuple[int, ...],
    tonality: Mode | Literal["both"],
) -> None:
    """
    Extend the in-process database (e.g. load from JSON on Replit startup).
    pitch_classes_from_root: semitone steps from root 0-11 within octave.
    """
    key = name.strip().lower().replace(" ", "_")
    pcs = normalize_pitch_classes(pitch_classes_from_root)
    _SCALE_DEFS[key] = pcs
    _SCALE_TONALITY[key] = tonality

_NOTE_NAMES = {
    "c": 0,
    "c#": 1,
    "db": 1,
    "d": 2,
    "d#": 3,
    "eb": 3,
    "e": 4,
    "f": 5,
    "f#": 6,
    "gb": 6,
    "g": 7,
    "g#": 8,
    "ab": 8,
    "a": 9,
    "a#": 10,
    "bb": 10,
    "b": 11,
}


class ScaleMismatchError(ValueError):
    """Raised when user scale does not fit detected major/minor and override is False."""


def parse_root(root: str) -> int:
    r = root.strip().lower().replace("♯", "#").replace("♭", "b")
    if r not in _NOTE_NAMES:
        raise ValueError(f"Unknown root: {root!r}")
    return _NOTE_NAMES[r]


def mido_key_signature_name(root_pc: int, mode: Mode) -> str:
    """
    Key string for ``mido.MetaMessage('key_signature', key=...)`` so DAWs show the right signature.
    Spelling is fixed per pitch-class (e.g. Db not C# for pc 1 major).
    """
    major = ("C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
    minor = ("Cm", "C#m", "Dm", "Ebm", "Em", "Fm", "F#m", "Gm", "Abm", "Am", "Bbm", "Bm")
    if mode == "major":
        return major[root_pc]
    return minor[root_pc]


def normalize_pitch_classes(pcs: Iterable[int]) -> tuple[int, ...]:
    s = {int(p) % 12 for p in pcs}
    return tuple(sorted(s))


def pitch_classes_for_named_scale(name: str) -> tuple[int, ...]:
    key = name.strip().lower().replace(" ", "_")
    if key not in _SCALE_DEFS:
        known = ", ".join(sorted(_SCALE_DEFS))
        raise KeyError(f"Unknown scale name {name!r}. Known: {known}")
    return _SCALE_DEFS[key]


def tonality_for_named_scale(scale_name: str) -> Mode | Literal["both"]:
    """Library tonality tag for major/minor gating (or inferred from intervals)."""
    key = scale_name.strip().lower().replace(" ", "_")
    if key not in _SCALE_DEFS:
        raise KeyError(f"Unknown scale name {scale_name!r}")
    rel = _SCALE_DEFS[key]
    return _SCALE_TONALITY.get(key, infer_tonality_from_pitch_classes(rel))


def scale_matches_detection(scale_name: str, detected_mode: Mode) -> bool:
    """True if named scale is allowed for the given detected key mode (without override)."""
    ton = tonality_for_named_scale(scale_name)
    if ton == "both":
        return True
    return ton == detected_mode


def list_registered_scales() -> list[str]:
    return sorted(_SCALE_DEFS.keys())


def find_exact_scale_matches(rel_from_root: tuple[int, ...]) -> list[str]:
    """Return all registered scale names whose interval set (from root 0) equals ``rel_from_root``."""
    target = set(normalize_pitch_classes(rel_from_root))
    return sorted(name for name, pcs in _SCALE_DEFS.items() if set(pcs) == target)


def infer_tonality_from_pitch_classes(pcs: tuple[int, ...]) -> Mode | Literal["both"]:
    """
    Heuristic: compare set to major / natural minor triad / common modes.
    """
    pcs_set = set(pcs)
    major_triad = {0, 4, 7}
    minor_triad = {0, 3, 7}
    has_major_third = bool(pcs_set & {i for i in range(12) if (i + 4) % 12 in pcs_set and i in pcs_set})
    # Simpler: check if scale contains major third from some implied root — expensive.
    # Instead: match against canonical scales from C root.
    majorish = 0
    minorish = 0
    for sname, ton in _SCALE_TONALITY.items():
        if ton == "both":
            continue
        if set(_SCALE_DEFS[sname]) == pcs_set:
            return "major" if ton == "major" else "minor"
        if pcs_set <= set(_SCALE_DEFS[sname]) or set(_SCALE_DEFS[sname]) <= pcs_set:
            if ton == "major":
                majorish += 1
            else:
                minorish += 1
    maj_template = set(_SCALE_DEFS["major"])
    min_template = set(_SCALE_DEFS["natural_minor"])
    overlap_maj = len(pcs_set & maj_template) / max(len(pcs_set), 1)
    overlap_min = len(pcs_set & min_template) / max(len(pcs_set), 1)
    if overlap_maj >= 0.85 and overlap_min < 0.85:
        return "major"
    if overlap_min >= 0.85 and overlap_maj < 0.85:
        return "minor"
    if major_triad <= pcs_set and minor_triad <= pcs_set:
        return "both"
    if minor_triad <= pcs_set and not (maj_template <= pcs_set):
        return "minor"
    if maj_template <= pcs_set or (major_triad <= pcs_set and 4 in [((p - min(pcs)) % 12) for p in pcs_set]):
        return "major"
    return "both"


@dataclass(frozen=True)
class ScaleResolution:
    root_pc: int
    pitch_classes: tuple[int, ...]  # absolute 0-11
    scale_name: str | None
    detected_mode: Mode
    user_tonality: Mode | Literal["both"]
    used_override: bool
    key_root: str  # as entered (e.g. Bb) for MIDI metadata / UI


def mido_key_signature_for_scale(scale: ScaleResolution) -> str:
    """
    Key signature matching the **notes in the file** (scale family), not only the detector.
    For ``both``-family scales, falls back to detected major/minor for DAW display.
    """
    if scale.user_tonality in ("major", "minor"):
        return mido_key_signature_name(scale.root_pc, scale.user_tonality)
    return mido_key_signature_name(scale.root_pc, scale.detected_mode)


def resolve_scale(
    detected_mode: Mode,
    root: str,
    *,
    user_scale_name: str | None = None,
    user_pitch_classes: Iterable[int] | None = None,
    forced_user_tonality: Mode | Literal["both"] | None = None,
    override: bool = False,
) -> ScaleResolution:
    """
    Pick pitch-class set for composition. Validates user scale vs detected_mode unless override.
    """
    root_pc = parse_root(root)
    if user_scale_name and user_pitch_classes is not None:
        raise ValueError("Provide either user_scale_name or user_pitch_classes, not both.")

    if user_scale_name:
        rel = pitch_classes_for_named_scale(user_scale_name)
        abs_pc = normalize_pitch_classes((root_pc + p) % 12 for p in rel)
        skey = user_scale_name.strip().lower().replace(" ", "_")
        user_ton = _SCALE_TONALITY.get(skey, infer_tonality_from_pitch_classes(rel))
    elif user_pitch_classes is not None:
        abs_pc = normalize_pitch_classes(user_pitch_classes)
        rel = normalize_pitch_classes((p - root_pc) % 12 for p in abs_pc)
        if forced_user_tonality is not None:
            user_ton = forced_user_tonality
        else:
            user_ton = infer_tonality_from_pitch_classes(rel)
        skey = None
    else:
        # Default: ionian for major detection, aeolian for minor
        if detected_mode == "major":
            rel = _SCALE_DEFS["major"]
            skey = "major"
        else:
            rel = _SCALE_DEFS["natural_minor"]
            skey = "natural_minor"
        abs_pc = normalize_pitch_classes((root_pc + p) % 12 for p in rel)
        user_ton = _SCALE_TONALITY[skey]

    if not override and user_ton != "both":
        if detected_mode == "major" and user_ton == "minor":
            raise ScaleMismatchError(
                f"Detected major key but scale {user_scale_name or rel!r} is minor-family. "
                "Use override=True to force."
            )
        if detected_mode == "minor" and user_ton == "major":
            raise ScaleMismatchError(
                f"Detected minor key but scale {user_scale_name or rel!r} is major-family. "
                "Use override=True to force."
            )

    return ScaleResolution(
        root_pc=root_pc,
        pitch_classes=abs_pc,
        scale_name=user_scale_name,
        detected_mode=detected_mode,
        user_tonality=user_ton,
        used_override=override and user_ton != "both",
        key_root=root.strip(),
    )


def relative_steps_from_root(abs_scale_pcs: tuple[int, ...], root_pc: int) -> tuple[int, ...]:
    """Semitone offsets from root within an octave, sorted ascending."""
    return tuple(sorted(((p - root_pc) % 12) for p in abs_scale_pcs))


def midi_for_scale_degree(
    root_pc: int,
    abs_scale_pcs: tuple[int, ...],
    degree: int,
    base_octave: int = 4,
) -> int:
    """Map linear scale degree (0 = lowest step in base octave) to MIDI note number."""
    if not abs_scale_pcs:
        raise ValueError("empty scale")
    rel = relative_steps_from_root(abs_scale_pcs, root_pc)
    n = len(rel)
    oct_jump, idx = divmod(degree, n)
    base_midi = 12 * (base_octave + oct_jump) + root_pc
    return base_midi + rel[idx]
