"""
Write monophonic MIDI tracks to files (one voice per file).
"""

from __future__ import annotations

from pathlib import Path

from mido import Message, MetaMessage, MidiFile, MidiTrack, bpm2tempo


def write_monophonic_midi(
    path: str | Path,
    *,
    bpm: float,
    ticks_per_beat: int,
    notes: list[tuple[int, int, int]],
    channel: int = 0,
    program: int | None = 24,
    track_name: str | None = None,
    key_signature_key: str | None = None,
) -> None:
    """
    notes: list of (pitch_midi, start_tick, duration_ticks). start_tick from timeline 0.
    Overlapping notes allowed; single track.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    mid = MidiFile(ticks_per_beat=ticks_per_beat)
    track = MidiTrack()
    mid.tracks.append(track)
    if track_name:
        track.append(MetaMessage("track_name", name=track_name[:127], time=0))
    track.append(MetaMessage("set_tempo", tempo=int(bpm2tempo(bpm)), time=0))
    if key_signature_key:
        track.append(MetaMessage("key_signature", key=key_signature_key, time=0))
    if program is not None:
        track.append(Message("program_change", channel=channel, program=program, time=0))

    events: list[tuple[int, str, int, int]] = []
    for pitch, start, dur in notes:
        if dur <= 0:
            continue
        events.append((start, "on", pitch, 0))
        events.append((start + dur, "off", pitch, 0))
    events.sort(key=lambda e: (e[0], 0 if e[1] == "on" else 1))

    t = 0
    for abs_tick, kind, pitch, _ in events:
        delta = max(0, abs_tick - t)
        t = abs_tick
        if kind == "on":
            track.append(
                Message("note_on", channel=channel, note=pitch, velocity=82, time=delta)
            )
        else:
            track.append(
                Message("note_off", channel=channel, note=pitch, velocity=0, time=delta)
            )
    mid.save(str(path))
