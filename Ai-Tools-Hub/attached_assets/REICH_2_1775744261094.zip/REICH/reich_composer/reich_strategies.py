"""
Steve Reich–style **heuristics** for this procedural engine (not a transcription of any score).

Grounded in published descriptions of *Electric Counterpoint* (1987) and Reich’s process-music
ideas; paraphrased for implementation. See also: CCRMA Stanford “Background on Electric
Counterpoint” (summarizes Reich’s program note); Boosey & Hawkes work page; Reich,
“Music as a Gradual Process” (transparent, gradual process; repetitive figures).

**Electric Counterpoint (abstractions we encode)**

- The tape texture stacks **many guitars** presenting material in **canon** (staggered entries),
  so the listener hears an **interlocking contrapuntal web**; the solo line often highlights
  patterns that **emerge** from that overlap rather than a separate “tune” in isolation.
- Other guitars/basses can sustain **pulsing / repeating harmonic** layers under the canons.
- Movements vary canon density (e.g. eight-part, nine-part, four-part + bass) and later add
  metric / tonal shifts (not fully modeled here — our **steady 16th pulse** matches the fast
  outer movements’ drive).

**Process music (composition discipline)**

- Prefer a **clear repeating cell**; let variety come from **rotation, canon, and grid offset**
  between voices rather than from constant new melodic invention.
- **Conjunct motion** keeps overlapping entries legible (idiomatic to guitar patterns Reich
  discussed with Metheny).
- **Audible structure**: the listener should be able to follow what repeats and how it shifts.

This module holds the constants and a small API used by ``patterns`` and ``composer``.
"""

from __future__ import annotations

import random
from typing import Final

# --- Textual reference (for UIs, logs, docs) ---------------------------------

ELECTRIC_COUNTERPOINT_POINTS: Final[tuple[str, ...]] = (
    "Stacked canons: same underlying pattern, staggered entries → interlocking texture.",
    "Solo or lead function: melodic interest from the composite counterpoint, not only one line.",
    "Harmonic rhythm: repeating/pulsing layers under canonic strands (rhythmic grid is explicit in our engine).",
)

PROCESS_MUSIC_POINTS: Final[tuple[str, ...]] = (
    "Repeating figure + process (rotation / entry delay) drives note-to-note detail.",
    "Change unfolds gradually; keep motion mostly stepwise within the scale.",
    "Structure should remain audible — repetition is a feature.",
)

# --- Melodic motion (scale-degree index deltas) -------------------------------

# Strong step bias, rare thirds — matches Reich-style guitar conjunct patterns.
REICH_DEGREE_DELTA_WEIGHTS: Final[tuple[tuple[int, float], ...]] = (
    (0, 0.20),
    (1, 0.395),
    (-1, 0.395),
    (2, 0.01),
    (-2, 0.01),
)

# --- Canon / interlock geometry ------------------------------------------------

COUNTERPOINT_MASTER_CELL_LENGTH: Final[int] = 12
HOCKET_MASTER_CELL_LENGTH: Final[int] = 24

# Rotation of the *shared* melodic cell per voice (16th-step cycle positions).
# Spreads entries like a short canon across one loop (12 / 3 = 4).
COUNTERPOINT_VOICE_ROTATIONS: Final[tuple[int, ...]] = (0, 4, 8)

# Six hocket voices: stagger across 24-step cell.
HOCKET_VOICE_ROTATIONS: Final[tuple[int, ...]] = (0, 4, 8, 12, 16, 20)


def reich_degree_delta(rng: random.Random) -> int:
    """Weighted random walk on linear scale-degree index (Reich electric preset)."""
    weights = REICH_DEGREE_DELTA_WEIGHTS
    total = sum(w for _, w in weights)
    t = rng.random() * total
    acc = 0.0
    for d, w in weights:
        acc += w
        if t <= acc:
            return d
    return 0


def strategies_for_api() -> dict[str, object]:
    """JSON-serializable summary for hosts that want to expose what the engine is doing."""
    return {
        "sources_note": (
            "Paraphrase of Reich Electric Counterpoint program material and process-music "
            "principles; heuristic procedural rules only."
        ),
        "electric_counterpoint": list(ELECTRIC_COUNTERPOINT_POINTS),
        "process_music": list(PROCESS_MUSIC_POINTS),
        "counterpoint": {
            "shared_master_cell": True,
            "cell_length_sixteenths": COUNTERPOINT_MASTER_CELL_LENGTH,
            "voice_rotations": list(COUNTERPOINT_VOICE_ROTATIONS),
        },
        "hocket_reich_style": {
            "shared_master_cell": True,
            "cell_length_sixteenths": HOCKET_MASTER_CELL_LENGTH,
            "voice_rotations": list(HOCKET_VOICE_ROTATIONS),
        },
    }
