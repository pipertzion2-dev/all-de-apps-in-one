"""
Algorithmic Reich / Shaw–inspired counterpoint and hocket MIDI generator.
"""

from reich_composer.scales import (
    ScaleResolution,
    resolve_scale,
    ScaleMismatchError,
    scale_matches_detection,
    list_registered_scales,
    infer_tonality_from_pitch_classes,
    pitch_classes_for_named_scale,
    register_user_scale,
)
from reich_composer.patterns import StyleName
from reich_composer.composer import (
    compose_three_voice_counterpoint,
    compose_six_voice_hocket,
    export_counterpoint_midis,
    export_hocket_midis,
    run_from_audio_params,
)
from reich_composer.reich_strategies import strategies_for_api

__all__ = [
    "StyleName",
    "ScaleResolution",
    "resolve_scale",
    "ScaleMismatchError",
    "scale_matches_detection",
    "list_registered_scales",
    "infer_tonality_from_pitch_classes",
    "pitch_classes_for_named_scale",
    "register_user_scale",
    "compose_three_voice_counterpoint",
    "compose_six_voice_hocket",
    "export_counterpoint_midis",
    "export_hocket_midis",
    "run_from_audio_params",
    "strategies_for_api",
]
