"""
3-voice Reich-style counterpoint and 6-voice hocket — MIDI export.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import random
from typing import Literal

from reich_composer.midi_writer import write_monophonic_midi
from reich_composer.patterns import (
    StyleName,
    build_melodic_cell,
    cell_to_midis,
    rotate_cell,
    voice_base_octave,
)
from reich_composer.reich_strategies import (
    COUNTERPOINT_MASTER_CELL_LENGTH,
    COUNTERPOINT_VOICE_ROTATIONS,
    HOCKET_MASTER_CELL_LENGTH,
    HOCKET_VOICE_ROTATIONS,
    strategies_for_api,
)
from reich_composer.scales import (
    ScaleResolution,
    mido_key_signature_for_scale,
    resolve_scale,
)

TicksPerBeat = 480


@dataclass
class VoicePart:
    voice_index: int
    notes: list[tuple[int, int, int]]  # pitch, start_tick, duration_ticks


def _total_sixteenths(duration_sec: float, bpm: float) -> int:
    beats = duration_sec * (bpm / 60.0)
    return max(1, int(round(beats * 4)))


def _sixteenth_duration_ticks(ticks_per_beat: int = TicksPerBeat) -> int:
    return ticks_per_beat // 4


def compose_three_voice_counterpoint(
    *,
    duration_sec: float,
    bpm: float,
    scale: ScaleResolution,
    style: StyleName = "reich_electric",
    seed: int | None = None,
    ticks_per_beat: int = TicksPerBeat,
) -> list[VoicePart]:
    rng = random.Random(seed)
    total = _total_sixteenths(duration_sec, bpm)
    dt = _sixteenth_duration_ticks(ticks_per_beat)
    base_cells: list[list[int]] = []

    if style == "phase_canon":
        cell_len = COUNTERPOINT_MASTER_CELL_LENGTH
        master = build_melodic_cell(
            scale.root_pc, scale.pitch_classes, cell_len, "reich_electric", rng, base_degree=0
        )
        for v in range(3):
            base_cells.append(rotate_cell(master, v * 4))
    elif style == "reich_electric":
        # One shared cell, canon rotations (Electric Counterpoint–style interlock).
        cell_len = COUNTERPOINT_MASTER_CELL_LENGTH
        master = build_melodic_cell(
            scale.root_pc, scale.pitch_classes, cell_len, "reich_electric", rng, base_degree=0
        )
        for v in range(3):
            base_cells.append(rotate_cell(master, COUNTERPOINT_VOICE_ROTATIONS[v]))
    else:
        cell_len = COUNTERPOINT_MASTER_CELL_LENGTH
        for v in range(3):
            r = random.Random((seed or 0) + v * 7919)
            base_cells.append(
                build_melodic_cell(
                    scale.root_pc,
                    scale.pitch_classes,
                    cell_len,
                    style,
                    r,
                    base_degree=v * 2,
                )
            )

    parts: list[VoicePart] = []
    for v in range(3):
        bo = voice_base_octave(v, 3, base_octave=4)
        seq_midis = cell_to_midis(scale.root_pc, scale.pitch_classes, base_cells[v], bo)
        notes: list[tuple[int, int, int]] = []
        s = v
        i = 0
        while s < total:
            if style == "shaw_interlace" and rng.random() < 0.12:
                s += 3
                i += 1
                continue
            pitch = seq_midis[i % len(seq_midis)]
            start = s * dt
            dur = max(1, dt - 2)
            notes.append((pitch, start, dur))
            s += 3
            i += 1
        parts.append(VoicePart(voice_index=v, notes=notes))
    return parts


def compose_six_voice_hocket(
    *,
    duration_sec: float,
    bpm: float,
    scale: ScaleResolution,
    style: StyleName = "reich_electric",
    seed: int | None = None,
    ticks_per_beat: int = TicksPerBeat,
) -> list[VoicePart]:
    rng = random.Random((seed or 0) ^ 0xC0FFEE)
    total = _total_sixteenths(duration_sec, bpm)
    dt = _sixteenth_duration_ticks(ticks_per_beat)
    cells: list[list[int]] = []
    if style == "phase_canon":
        cell_len = HOCKET_MASTER_CELL_LENGTH
        master = build_melodic_cell(
            scale.root_pc, scale.pitch_classes, cell_len, "reich_electric", rng
        )
        for v in range(6):
            cells.append(rotate_cell(master, v * 3))
    elif style == "reich_electric":
        cell_len = HOCKET_MASTER_CELL_LENGTH
        master = build_melodic_cell(
            scale.root_pc, scale.pitch_classes, cell_len, "reich_electric", rng, base_degree=0
        )
        for v in range(6):
            cells.append(rotate_cell(master, HOCKET_VOICE_ROTATIONS[v]))
    else:
        cell_len = HOCKET_MASTER_CELL_LENGTH
        for v in range(6):
            r = random.Random((seed or 0) + v * 104729)
            cells.append(
                build_melodic_cell(
                    scale.root_pc,
                    scale.pitch_classes,
                    cell_len,
                    style,
                    r,
                    base_degree=v,
                )
            )

    parts: list[VoicePart] = []
    for v in range(6):
        bo = voice_base_octave(v, 6, base_octave=4)
        seq_midis = cell_to_midis(scale.root_pc, scale.pitch_classes, cells[v], bo)
        notes: list[tuple[int, int, int]] = []
        s = v
        i = 0
        while s < total:
            if style == "shaw_interlace" and rng.random() < 0.18:
                s += 6
                i += 1
                continue
            pitch = seq_midis[i % len(seq_midis)]
            start = s * dt
            dur = max(1, dt - 1)
            notes.append((pitch, start, dur))
            s += 6
            i += 1
        parts.append(VoicePart(voice_index=v, notes=notes))
    return parts


def export_counterpoint_midis(
    parts: list[VoicePart],
    out_dir: str | Path,
    *,
    bpm: float,
    scale: ScaleResolution,
    prefix: str = "reich_cp",
    ticks_per_beat: int = TicksPerBeat,
) -> list[Path]:
    if len(parts) != 3:
        raise ValueError("expected 3 VoicePart for counterpoint export")
    out_dir = Path(out_dir)
    paths: list[Path] = []
    ks = mido_key_signature_for_scale(scale)
    for p in parts:
        fn = out_dir / f"{prefix}_voice{p.voice_index + 1}.mid"
        sn = scale.scale_name or "default_scale"
        tn = f"Reich CP{p.voice_index + 1} | {scale.key_root} | {sn}"
        write_monophonic_midi(
            fn,
            bpm=bpm,
            ticks_per_beat=ticks_per_beat,
            notes=p.notes,
            track_name=tn,
            key_signature_key=ks,
        )
        paths.append(fn)
    return paths


def export_hocket_midis(
    parts: list[VoicePart],
    out_dir: str | Path,
    *,
    bpm: float,
    scale: ScaleResolution,
    prefix: str = "reich_hocket",
    ticks_per_beat: int = TicksPerBeat,
) -> list[Path]:
    if len(parts) != 6:
        raise ValueError("expected 6 VoicePart for hocket export")
    out_dir = Path(out_dir)
    paths: list[Path] = []
    ks = mido_key_signature_for_scale(scale)
    for p in parts:
        fn = out_dir / f"{prefix}_voice{p.voice_index + 1}.mid"
        sn = scale.scale_name or "default_scale"
        tn = f"Reich HK{p.voice_index + 1} | {scale.key_root} | {sn}"
        write_monophonic_midi(
            fn,
            bpm=bpm,
            ticks_per_beat=ticks_per_beat,
            notes=p.notes,
            track_name=tn,
            key_signature_key=ks,
        )
        paths.append(fn)
    return paths


def run_from_audio_params(
    *,
    duration_sec: float,
    bpm: float,
    detected_mode: Literal["major", "minor"],
    key_root: str,
    out_dir: str,
    user_scale_name: str | None = None,
    user_pitch_classes: list[int] | None = None,
    forced_user_tonality: Literal["major", "minor", "both"] | None = None,
    override_scale: bool = False,
    counterpoint_style: StyleName = "reich_electric",
    hocket_style: StyleName = "reich_electric",
    seed: int | None = None,
) -> dict:
    """
    High-level entry for Replit: validates scale, composes both sections, exports 3+6 MIDI files.
    """
    scale = resolve_scale(
        detected_mode,
        key_root,
        user_scale_name=user_scale_name,
        user_pitch_classes=user_pitch_classes,
        forced_user_tonality=forced_user_tonality,
        override=override_scale,
    )
    cp = compose_three_voice_counterpoint(
        duration_sec=duration_sec,
        bpm=bpm,
        scale=scale,
        style=counterpoint_style,
        seed=seed,
    )
    hk = compose_six_voice_hocket(
        duration_sec=duration_sec,
        bpm=bpm,
        scale=scale,
        style=hocket_style,
        seed=seed,
    )
    out = Path(out_dir)
    cp_paths = export_counterpoint_midis(cp, out, bpm=bpm, scale=scale, prefix="reich_counterpoint")
    hk_paths = export_hocket_midis(hk, out, bpm=bpm, scale=scale, prefix="reich_hocket")
    return {
        "scale": scale,
        "counterpoint_paths": [str(p) for p in cp_paths],
        "hocket_paths": [str(p) for p in hk_paths],
        "composition_strategies": strategies_for_api(),
    }
