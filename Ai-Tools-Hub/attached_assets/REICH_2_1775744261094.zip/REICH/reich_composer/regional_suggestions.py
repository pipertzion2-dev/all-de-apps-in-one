"""
Broad regional queries ("indian", "chinese", "arabic") → specific built-in scale names.
"""

from __future__ import annotations

import re
from typing import Callable, Literal

from reich_composer.scales import list_registered_scales, scale_matches_detection

Mode = Literal["major", "minor"]


class VagueScaleQueryError(ValueError):
    """User typed a region/style, not a single scale — carries clickable suggestions."""

    def __init__(
        self,
        message: str,
        suggestions: list[str],
        *,
        category: str = "Regional",
        detected_mode: Mode | None = None,
        suggestions_fit: list[str] | None = None,
        suggestions_mismatch: list[str] | None = None,
    ) -> None:
        super().__init__(message)
        self.suggestions = suggestions
        self.category = category
        self.detected_mode = detected_mode
        self.suggestions_fit = suggestions_fit if suggestions_fit is not None else list(suggestions)
        self.suggestions_mismatch = suggestions_mismatch if suggestions_mismatch is not None else []


def _all_starting(prefixes: tuple[str, ...]) -> list[str]:
    return sorted(n for n in list_registered_scales() if n.startswith(prefixes))


def _indian() -> list[str]:
    return _all_starting(("raga_", "carnatic_"))


def _carnatic_only() -> list[str]:
    return _all_starting(("carnatic_",))


def _chinese() -> list[str]:
    return _all_starting(("chinese_",))


def _japanese() -> list[str]:
    return _all_starting(("japanese_",))


def _arabic() -> list[str]:
    return _all_starting(("arabic_",))


def _turkish() -> list[str]:
    return _all_starting(("turkish_",))


def _korean() -> list[str]:
    return _all_starting(("korean_",))


def _african() -> list[str]:
    return _all_starting(("ethiopian_",))


def _asian_mixed() -> list[str]:
    s: set[str] = set()
    s.update(_chinese(), _japanese(), _korean())
    return sorted(s)


def _middle_eastern() -> list[str]:
    s: set[str] = set()
    s.update(_arabic(), _turkish())
    return sorted(s)


def broad_regional_suggestions(raw: str) -> tuple[str, str, list[str]] | None:
    """
    If ``raw`` is a broad culture/region hint, return
    ``(category_title, message, suggestion_scale_names)``.
    Otherwise return None.
    """
    text = raw.strip()
    if not text:
        return None
    ql = text.lower()
    compact = re.sub(r"[^a-z0-9]", "", ql)

    def hit(*substrings: str) -> bool:
        return any(s in ql for s in substrings) or any(
            compact == re.sub(r"[^a-z0-9]", "", s) for s in substrings
        )

    rules: list[tuple[Callable[[], bool], str, str, Callable[[], list[str]]]] = [
        (lambda: hit("carnatic") and not hit("indian", "hindustani"), "Carnatic", "Carnatic melakarta-style sets (12-TET):", _carnatic_only),
        (lambda: hit("indian", "hindustani", "bharat") or compact in ("india", "indian"), "Indian classical", "Hindustani ragas and Carnatic sets — pick one:", _indian),
        (lambda: compact in ("raga", "ragas") or ql.strip() in ("raga", "ragas"), "Indian classical", "Raga names in the library — pick one:", _indian),
        (lambda: hit("chinese", "china", "mandarin"), "Chinese", "Pentatonic modes from root (12-TET sketch):", _chinese),
        (lambda: hit("japanese", "japan", "okinawa"), "Japanese", "Pentatonic approximations (in / yo):", _japanese),
        (lambda: hit("korean", "korea"), "Korean", "Pentatonic-style sets:", _korean),
        (lambda: hit("arabic", "maqam", "maqamat"), "Arabic maqam", "Common maqam skeletons (12-TET):", _arabic),
        (lambda: hit("turkish", "turkey", "istanbul"), "Turkish makam", "Makam-style approximations:", _turkish),
        (lambda: hit("middle eastern", "middle-eastern", "levant", "persian", "iranian"), "Middle Eastern", "Arabic and Turkish-style sets:", _middle_eastern),
        (lambda: hit("african", "ethiopian", "eritrean"), "African", "Ethiopian-style approximations:", _african),
        (lambda: hit("asian") and not hit("indian") and "middle" not in ql, "East Asian", "Chinese, Japanese, and Korean sets:", _asian_mixed),
    ]

    for pred, title, msg, lst_fn in rules:
        try:
            if pred():
                names = lst_fn()
                if names:
                    return (title, msg, names)
        except Exception:
            continue
    return None


def _partition_for_detection(names: list[str], detected_mode: Mode) -> tuple[list[str], list[str]]:
    fit: list[str] = []
    mismatch: list[str] = []
    for n in names:
        if scale_matches_detection(n, detected_mode):
            fit.append(n)
        else:
            mismatch.append(n)
    return fit, mismatch


def raise_if_broad_query(raw: str, detected_mode: Mode | None = None) -> None:
    """Raise VagueScaleQueryError with suggestions, or return if not a broad query."""
    got = broad_regional_suggestions(raw)
    if not got:
        return
    title, msg, names = got
    fit = list(names)
    mismatch: list[str] = []
    ordered = list(names)
    mode_note = ""
    if detected_mode is not None:
        fit, mismatch = _partition_for_detection(names, detected_mode)
        ordered = fit + mismatch
        cap = detected_mode.capitalize()
        mode_note = (
            f" For {cap} detection, scales that match without Override are listed first; "
            "the rest need “Override scale mismatch” (or change detected mode)."
        )
    preview = ", ".join(ordered[:24])
    if len(ordered) > 24:
        preview += f" … (+{len(ordered) - 24} more)"
    raise VagueScaleQueryError(
        f"{msg}{mode_note} {preview}",
        ordered,
        category=title,
        detected_mode=detected_mode,
        suggestions_fit=fit,
        suggestions_mismatch=mismatch,
    )
