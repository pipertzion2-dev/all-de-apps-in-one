"""
Melodic cells and style presets (Reich, Shaw, phase canon).
"""

from __future__ import annotations

import random
from typing import Literal

from reich_composer.reich_strategies import reich_degree_delta
from reich_composer.scales import midi_for_scale_degree

StyleName = Literal["reich_electric", "shaw_interlace", "phase_canon"]


def _reich_degree_delta(rng: random.Random) -> int:
    """Reich electric: conjunct-biased walk (see ``reich_strategies``)."""
    return reich_degree_delta(rng)


def _shaw_degree_delta(rng: random.Random) -> int:
    weights = [(0, 0.15), (1, 0.3), (-1, 0.3), (2, 0.1), (-2, 0.1), (3, 0.03), (-3, 0.02)]
    total = sum(w for _, w in weights)
    t = rng.random() * total
    acc = 0.0
    for d, w in weights:
        acc += w
        if t <= acc:
            return d
    return 0


def build_melodic_cell(
    root_pc: int,
    abs_scale_pcs: tuple[int, ...],
    length: int,
    style: StyleName,
    rng: random.Random,
    base_degree: int = 0,
) -> list[int]:
    """
    Returns list of scale degrees (linear index into scale) length `length`.
    """
    n = max(len(abs_scale_pcs), 1)
    deg = base_degree % (n * 3) + n
    out: list[int] = []
    for _ in range(length):
        if style == "reich_electric":
            deg += _reich_degree_delta(rng)
        elif style == "shaw_interlace":
            if rng.random() < 0.08:
                pass
            else:
                deg += _shaw_degree_delta(rng)
        else:
            deg += _reich_degree_delta(rng)
        lo, hi = n, n * 5
        deg = max(lo, min(hi, deg))
        out.append(deg)
    return out


def rotate_cell(cell: list[int], k: int) -> list[int]:
    if not cell:
        return cell
    k %= len(cell)
    return cell[k:] + cell[:k]


def cell_to_midis(
    root_pc: int,
    abs_scale_pcs: tuple[int, ...],
    degrees: list[int],
    base_octave: int,
) -> list[int]:
    return [midi_for_scale_degree(root_pc, abs_scale_pcs, d, base_octave) for d in degrees]


def voice_base_octave(voice_index: int, num_voices: int, base_octave: int = 4) -> int:
    spread = [0, 0, 1, 1, 2, 2][:num_voices]
    if voice_index < len(spread):
        return base_octave + spread[voice_index]
    return base_octave + voice_index // 2
