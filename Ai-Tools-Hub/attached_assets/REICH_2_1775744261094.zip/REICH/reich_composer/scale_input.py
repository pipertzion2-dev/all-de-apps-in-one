"""
Parse user-entered scale intervals and summarize for UI / API.
"""

from __future__ import annotations

import re
from typing import Any, Literal

from reich_composer.regional_suggestions import VagueScaleQueryError
from reich_composer.scale_query import resolve_named_scale_to_intervals
from reich_composer.scales import (
    find_exact_scale_matches,
    infer_tonality_from_pitch_classes,
    normalize_pitch_classes,
    parse_root,
)

Mode = Literal["major", "minor"]


def parse_intervals_text(text: str) -> tuple[int, ...]:
    if not text or not str(text).strip():
        raise ValueError("Enter intervals from your key root (e.g. 0,2,4,5,7,9,11).")
    parts = re.split(r"[\s,;|]+", str(text).strip())
    nums: list[int] = []
    for p in parts:
        if not p:
            continue
        try:
            nums.append(int(p) % 12)
        except ValueError as e:
            raise ValueError(
                f"Not a valid semitone number: {p!r}. Use digits only, or type a raga name alone (e.g. yaman)."
            ) from e
    if not nums:
        raise ValueError("No numbers found. Use semitones from the root (0 = root, 2 = major 2nd, …).")
    rel = normalize_pitch_classes(nums)
    if len(rel) < 2:
        raise ValueError("Need at least two distinct pitch classes in the octave.")
    return rel


def parse_intervals_or_scale_name(
    text: str, *, detected_mode: Mode | None = None
) -> tuple[int, ...]:
    """Numbers → intervals; otherwise treat as a named scale / raga (e.g. yaman, raga_bhairavi)."""
    t = str(text).strip()
    if not t:
        raise ValueError("Enter intervals (e.g. 0,2,4,5) or a scale/raga name (e.g. yaman, bhairavi).")
    try:
        return parse_intervals_text(t)
    except ValueError:
        return resolve_named_scale_to_intervals(t, detected_mode=detected_mode)


def intervals_to_absolute_pitch_classes(key_root: str, rel: tuple[int, ...]) -> tuple[int, ...]:
    root_pc = parse_root(key_root)
    return normalize_pitch_classes((root_pc + r) % 12 for r in rel)


def analyze_scale_input(
    key_root: str,
    detected_mode: Mode,
    intervals_text: str,
    forced_tonality: Literal["auto", "major", "minor", "both"],
) -> dict[str, Any]:
    try:
        rel = parse_intervals_or_scale_name(intervals_text, detected_mode=detected_mode)
    except VagueScaleQueryError as e:
        return {
            "ok": True,
            "broad_query": True,
            "category": e.category,
            "suggestions": e.suggestions,
            "suggestions_fit": e.suggestions_fit,
            "suggestions_mismatch": e.suggestions_mismatch,
            "message": str(e),
            "summary_lines": [str(e)],
            "intervals_relative": [],
            "intervals_display": "",
            "pitch_classes_absolute": [],
            "inferred_tonality": "both",
            "forced_tonality": None,
            "effective_tonality": "both",
            "database_matches": [],
            "compatible_with_detection": True,
            "detected_mode": detected_mode,
        }
    inferred = infer_tonality_from_pitch_classes(rel)
    if forced_tonality == "auto":
        effective: Any = inferred
    else:
        effective = forced_tonality

    matches = find_exact_scale_matches(rel)
    abs_pc = intervals_to_absolute_pitch_classes(key_root, rel)

    compatible = True
    if effective != "both":
        if detected_mode == "major" and effective == "minor":
            compatible = False
        if detected_mode == "minor" and effective == "major":
            compatible = False

    lines: list[str] = []
    lines.append(
        f"Intervals from {key_root.strip().upper()} root: "
        + ", ".join(str(x) for x in rel)
        + " (semitone steps within an octave)."
    )
    if matches:
        lines.append("Exact matches in the scale library: " + ", ".join(matches) + ".")
    else:
        lines.append("No exact name match in the library — using your intervals as a custom scale.")
    lines.append(f"Inferred family: {inferred}. Effective rule for gating: {effective}.")
    if not compatible:
        lines.append(
            f"Detected audio mode is {detected_mode}, but this scale is treated as {effective}-family. "
            "Enable “Override scale mismatch” to compose anyway."
        )
    else:
        lines.append(f"Compatible with detected {detected_mode} (or marked “both”).")

    return {
        "ok": True,
        "intervals_relative": list(rel),
        "intervals_display": ", ".join(str(x) for x in rel),
        "pitch_classes_absolute": list(abs_pc),
        "inferred_tonality": inferred,
        "forced_tonality": None if forced_tonality == "auto" else forced_tonality,
        "effective_tonality": effective,
        "database_matches": matches,
        "compatible_with_detection": compatible,
        "detected_mode": detected_mode,
        "summary_lines": lines,
    }
