"""
Resolve free-text scale queries (e.g. "yaman", "raga bhairavi", "indian") to interval sets.
"""

from __future__ import annotations

import re
from typing import Literal

from reich_composer.online_scale_lookup import (
    lookup_scale_intervals_online,
    offline_lookup_hint,
)
from reich_composer.regional_suggestions import raise_if_broad_query
from reich_composer.scales import list_registered_scales, pitch_classes_for_named_scale

Mode = Literal["major", "minor"]


def _normalize_query(raw: str) -> str:
    s = raw.strip().lower()
    s = re.sub(r"[\s\-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def _strip_raga_prefix(q: str) -> str:
    if q.startswith("raga_"):
        return q[5:].lstrip("_")
    return q


def resolve_named_scale_to_intervals(
    raw: str, *, detected_mode: Mode | None = None
) -> tuple[int, ...]:
    """
    Turn a library scale name or short alias (``yaman``, ``bhairavi``) into
    pitch classes from root. Raises ValueError with a helpful message if ambiguous.
    """
    q = _normalize_query(raw)
    if not q:
        raise ValueError("Enter a raga name (e.g. yaman, bhairavi) or numeric intervals.")

    raise_if_broad_query(raw.strip(), detected_mode)

    all_keys = list_registered_scales()

    if q in all_keys:
        return pitch_classes_for_named_scale(q)

    for prefix in ("raga_", "carnatic_"):
        cand = prefix + q
        if cand in all_keys:
            return pitch_classes_for_named_scale(cand)

    short = _strip_raga_prefix(q)
    if short != q:
        if not short:
            raise_if_broad_query("raga", detected_mode)
        for prefix in ("raga_", "carnatic_"):
            cand = prefix + short
            if cand in all_keys:
                return pitch_classes_for_named_scale(cand)

    # substring match: unique only
    matches = [
        k
        for k in all_keys
        if q in k
        or k.endswith("_" + q)
        or k.replace("raga_", "").replace("carnatic_", "") == q
    ]
    matches = sorted(set(matches))
    if len(matches) == 1:
        return pitch_classes_for_named_scale(matches[0])
    if len(matches) > 1:
        preview = ", ".join(matches[:12])
        more = f" (+{len(matches) - 12} more)" if len(matches) > 12 else ""
        raise ValueError(f"Ambiguous “{raw}”. Matches: {preview}{more}. Type the full scale key.")

    online = lookup_scale_intervals_online(raw.strip())
    if online is not None:
        return online

    hint = offline_lookup_hint()
    extra = f" {hint}" if hint else ""
    raise ValueError(
        f"Unknown scale “{raw}” (not in the built-in library and online lookup did not return intervals). "
        f"Try numeric semitones, or enable SCALE_LOOKUP_ONLINE=1 with OPENAI_API_KEY / SCALE_CATALOG_URL.{extra}"
    )
