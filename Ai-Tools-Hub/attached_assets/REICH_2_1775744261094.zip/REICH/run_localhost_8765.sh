#!/usr/bin/env bash
# Serves this repo at http://localhost:8765/ (fails if 8765 is already taken).
set -euo pipefail
cd "$(dirname "$0")"
export PORT=8765
export STRICT_PORT=1
exec .venv/bin/python web_app.py
