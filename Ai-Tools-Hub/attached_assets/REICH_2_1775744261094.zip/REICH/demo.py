#!/usr/bin/env python3
"""Quick local test: writes 3 + 6 MIDI files to ./midi_out"""

from pathlib import Path

from replit_entry import check_scale_for_key, compose_from_detection

OUT = Path(__file__).resolve().parent / "midi_out"
OUT.mkdir(exist_ok=True)

# Example: Dorian does not match a *major* detection (UI would ask for override).
print("Scale check:", check_scale_for_key("dorian", "major"))

result = compose_from_detection(
    duration_sec=8.0,
    bpm=108,
    detected_mode="minor",
    key_root="E",
    out_dir=str(OUT),
    user_scale_name="dorian",
    counterpoint_style="reich_electric",
    hocket_style="reich_electric",
    seed=42,
)

print("Counterpoint (3 files):")
for p in result["counterpoint_paths"]:
    print(" ", p)
print("Hocket (6 files):")
for p in result["hocket_paths"]:
    print(" ", p)
print("Done. Open the .mid files in a DAW or quick look.")
