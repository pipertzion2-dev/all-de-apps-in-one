"""
Local web UI for Safari / any browser (default port 8765 — see __main__).
"""

from __future__ import annotations

import io
import zipfile
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file

from reich_composer import ScaleMismatchError, list_registered_scales
from reich_composer.regional_suggestions import VagueScaleQueryError
from reich_composer.scales import parse_root, tonality_for_named_scale
from reich_composer.scale_input import (
    analyze_scale_input,
    intervals_to_absolute_pitch_classes,
    parse_intervals_or_scale_name,
)
from reich_composer.online_scale_lookup import lookup_status
from reich_composer.reich_strategies import strategies_for_api
from replit_entry import compose_from_detection

_WORLD_PREFIXES = ("chinese_", "arabic_", "japanese_", "turkish_", "korean_", "ethiopian_")


def _scale_groups() -> tuple[list[str], list[str], list[str]]:
    """Indian ragas/melakartas, other world approximations, Western & remaining."""
    all_s = list_registered_scales()
    indian = sorted(s for s in all_s if s.startswith("raga_") or s.startswith("carnatic_"))
    indian_set = frozenset(indian)
    rest = [s for s in all_s if s not in indian_set]
    world = sorted(s for s in rest if s.startswith(_WORLD_PREFIXES))
    wset = frozenset(world)
    western = sorted(s for s in rest if s not in wset)
    return indian, world, western


def _scales_ui_rows(scale_names: list[str]) -> list[dict[str, str]]:
    return [{"name": n, "tonality": tonality_for_named_scale(n)} for n in scale_names]


def _render_index(**kwargs):
    indian, world, western = _scale_groups()
    ctx: dict = {
        "scales_indian": _scales_ui_rows(indian),
        "scales_world": _scales_ui_rows(world),
        "scales_other": _scales_ui_rows(western),
        "lookup_status": lookup_status(),
        "error": None,
        "scale_suggestions_fit": None,
        "scale_suggestions_mismatch": None,
        "error_detected_mode": None,
    }
    ctx.update(kwargs)
    return render_template("index.html", **ctx)


app = Flask(__name__)
# Without this, Flask/Jinja cache templates when DEBUG is False — edits to
# templates/index.html would not show until you kill and restart Waitress.
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.after_request
def _no_store_html(response):
    """So a normal browser refresh always fetches the latest template (not a stale cached copy)."""
    if request.method == "GET" and response.content_type and "text/html" in response.content_type:
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
    return response


@app.get("/ping")
def ping():
    return "ok", 200, {"Content-Type": "text/plain; charset=utf-8"}


@app.get("/")
def index():
    return _render_index()


@app.post("/api/scale-finder")
def api_scale_finder():
    """Analyze custom intervals: library match, inferred tonality, compatibility with detection."""
    data = request.get_json(silent=True) or {}
    key_root = (data.get("key_root") or "C").strip()
    detected_mode = data.get("detected_mode") or "minor"
    if detected_mode not in ("major", "minor"):
        detected_mode = "minor"
    intervals_text = data.get("intervals_text") or ""
    forced = data.get("forced_tonality") or "auto"
    if forced not in ("auto", "major", "minor", "both"):
        forced = "auto"
    try:
        parse_root(key_root)
    except ValueError as e:
        return jsonify(ok=False, error=str(e)), 400
    try:
        result = analyze_scale_input(key_root, detected_mode, intervals_text, forced)
        result["lookup_status"] = lookup_status()
        return jsonify(**result)
    except ValueError as e:
        msg = str(e)
        out: dict = {"ok": False, "error": msg}
        out["lookup_status"] = lookup_status()
        return jsonify(out), 400


@app.get("/api/lookup-status")
def api_lookup_status():
    """Whether online scale lookup is configured (no secrets exposed)."""
    return jsonify(lookup_status())


@app.get("/api/composition-strategies")
def api_composition_strategies():
    """Reich-style canonic / process-music heuristics this app uses (JSON reference)."""
    return jsonify(strategies_for_api())


@app.post("/compose")
def compose():
    try:
        duration_sec = float(request.form.get("duration_sec", "8"))
        bpm = float(request.form.get("bpm", "120"))
        detected_mode = request.form.get("detected_mode", "minor")
        if detected_mode not in ("major", "minor"):
            detected_mode = "minor"
        key_root = (request.form.get("key_root") or "C").strip()
        scale_source = request.form.get("scale_source", "preset")
        custom_intervals = (request.form.get("custom_intervals") or "").strip()
        custom_tonality = request.form.get("custom_tonality", "auto")
        if custom_tonality not in ("auto", "major", "minor", "both"):
            custom_tonality = "auto"

        cp_style = request.form.get("counterpoint_style") or "reich_electric"
        hk_style = request.form.get("hocket_style") or "reich_electric"
        if cp_style not in ("reich_electric", "shaw_interlace", "phase_canon"):
            cp_style = "reich_electric"
        if hk_style not in ("reich_electric", "shaw_interlace", "phase_canon"):
            hk_style = "reich_electric"
        override = request.form.get("override_scale") == "1"
        seed_raw = request.form.get("seed", "").strip()
        seed = int(seed_raw) if seed_raw else None
    except ValueError:
        dm = request.form.get("detected_mode", "minor")
        if dm not in ("major", "minor"):
            dm = "minor"
        return _render_index(error="Invalid number in the form.", error_detected_mode=dm), 400

    user_scale_name: str | None = None
    user_pitch_classes: list[int] | None = None
    forced_for_resolve: str | None = None

    if scale_source == "custom":
        forced_for_resolve = None if custom_tonality == "auto" else custom_tonality
        try:
            rel = parse_intervals_or_scale_name(
                custom_intervals, detected_mode=detected_mode
            )
            user_pitch_classes = list(intervals_to_absolute_pitch_classes(key_root, rel))
        except VagueScaleQueryError as e:
            return (
                _render_index(
                    error=str(e),
                    scale_suggestions_fit=e.suggestions_fit,
                    scale_suggestions_mismatch=e.suggestions_mismatch,
                    error_detected_mode=detected_mode,
                ),
                400,
            )
        except ValueError as e:
            return (
                _render_index(error=str(e), error_detected_mode=detected_mode),
                400,
            )
    else:
        raw_scale = (request.form.get("user_scale_name") or "").strip()
        user_scale_name = raw_scale if raw_scale else None
        forced_for_resolve = None

    import tempfile

    try:
        with tempfile.TemporaryDirectory() as d:
            result = compose_from_detection(
                duration_sec=duration_sec,
                bpm=bpm,
                detected_mode=detected_mode,
                key_root=key_root,
                out_dir=d,
                user_scale_name=user_scale_name,
                user_pitch_classes=user_pitch_classes,
                forced_user_tonality=forced_for_resolve,
                override_scale=override,
                counterpoint_style=cp_style,
                hocket_style=hk_style,
                seed=seed,
            )
            paths = [Path(p) for p in result["counterpoint_paths"] + result["hocket_paths"]]
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in paths:
                    zf.write(p, p.name)
            buf.seek(0)
            return send_file(
                buf,
                as_attachment=True,
                download_name="reich_midi.zip",
                mimetype="application/zip",
            )
    except ScaleMismatchError as e:
        return (
            _render_index(error=str(e), error_detected_mode=detected_mode),
            400,
        )


def _can_bind(family: int, addr: tuple) -> bool:
    import socket

    s = socket.socket(family, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(addr)
        return True
    except OSError:
        return False
    finally:
        s.close()


def _pick_loopback_port(preferred: int, span: int = 40) -> tuple[int, bool]:
    import socket

    for p in range(preferred, preferred + span):
        if not _can_bind(socket.AF_INET, ("127.0.0.1", p)):
            continue
        v6 = False
        try:
            v6 = _can_bind(socket.AF_INET6, ("::1", p))
        except OSError:
            v6 = False
        return p, v6
    raise SystemExit(
        f"No free TCP port near {preferred} on 127.0.0.1 (tried {span}). Set PORT=..."
    )


def _port_for_listen(preferred: int, strict: bool) -> tuple[int, bool]:
    """If strict, use exactly ``preferred`` or exit (for http://localhost:8765/)."""
    import socket

    if not strict:
        return _pick_loopback_port(preferred, span=40)
    if not _can_bind(socket.AF_INET, ("127.0.0.1", preferred)):
        raise SystemExit(
            f"Port {preferred} is in use. Stop the other process using it, then run again.\n"
            f"  Example: lsof -i :{preferred}\n"
            "  Or run without STRICT_PORT=1 to auto-pick the next free port."
        )
    v6 = False
    try:
        v6 = _can_bind(socket.AF_INET6, ("::1", preferred))
    except OSError:
        v6 = False
    return preferred, v6


def _schedule_self_check(port: int) -> None:
    import threading
    import urllib.error
    import urllib.request

    urls = [
        f"http://127.0.0.1:{port}/ping",
        f"http://[::1]:{port}/ping",
    ]

    def attempt(n: int = 0) -> None:
        for url in urls:
            try:
                with urllib.request.urlopen(url, timeout=2) as r:
                    if r.read().decode().strip() == "ok":
                        print(f"\n  Self-check OK — {url}")
                        print(f"  Main UI: http://127.0.0.1:{port}/  or  http://localhost:{port}/")
                        return
            except (urllib.error.URLError, OSError):
                continue
        if n < 10:
            threading.Timer(0.35, lambda: attempt(n + 1)).start()
        else:
            print("\n  Self-check: could not reach /ping.")
            print("  Confirm this terminal shows Waitress 'serving on' lines and no traceback above.")

    threading.Timer(0.4, lambda: attempt(0)).start()


def _maybe_open_browser(port: int) -> None:
    if __import__("os").environ.get("OPEN_BROWSER") != "1":
        return
    import threading
    import time
    import webbrowser

    def _go() -> None:
        time.sleep(0.8)
        webbrowser.open(f"http://127.0.0.1:{port}/")

    threading.Thread(target=_go, daemon=True).start()


if __name__ == "__main__":
    import os
    from pathlib import Path as _Path

    _here = _Path(__file__).resolve().parent
    print(f"  HTML templates: {_here / 'templates'}")
    print("  (Edit index.html here — with auto-reload on, save and refresh the browser.)\n")

    preferred = int(os.environ.get("PORT", "8765"))
    strict = os.environ.get("STRICT_PORT", "").lower() in ("1", "true", "yes")
    port, ipv6_ok = _port_for_listen(preferred, strict=strict)
    if not strict and port != preferred:
        print(f"  Note: port {preferred} was busy — using {port} instead.")

    listen = [f"127.0.0.1:{port}"]
    if ipv6_ok:
        listen.append(f"[::1]:{port}")

    print("Reich composer — web UI (Waitress)")
    print(f"  Serving on: {' '.join(listen)}")
    print(f"  Open:  http://127.0.0.1:{port}/")
    print(f"  Open:  http://localhost:{port}/   (works if IPv6 [::1] is enabled)")
    print(f"  Ping:  http://127.0.0.1:{port}/ping  → must show ok")
    print("  Use Safari or Chrome — Cursor’s built-in browser often fails on localhost.")
    print("  Optional: OPEN_BROWSER=1 to open your default browser automatically.")
    if os.environ.get("SSH_CONNECTION"):
        print("  You are in SSH: Safari on your laptop is NOT the same machine — forward the port or run on the Mac.")
    print("  Keep this terminal open.\n")

    if os.environ.get("NO_SELF_CHECK") != "1":
        _schedule_self_check(port)
    _maybe_open_browser(port)

    try:
        from waitress import serve

        serve(app, listen=listen, threads=8)
    except ImportError:
        print("Waitress not installed. Run: pip install -r requirements.txt")
        print("Falling back to Flask dev server on 127.0.0.1 only …")
        app.run(host="127.0.0.1", port=port, debug=False, threaded=True, use_reloader=False)
