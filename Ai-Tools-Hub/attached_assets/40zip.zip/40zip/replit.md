# Free Online Build Planner Tool — Svivva

## Overview
A single-page static web application ("engineering as marketing" tool) that provides a fast preview of Svivva's production workflows. Users enter a project description, select a category, and receive a production-style preview (schematic, BOM, flow graph, idea report, etc.). Optimized for Google Search to drive organic traffic to svivva.com.

## Tech Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript (ES6)
- **Styling**: Custom CSS with CSS variables, Flexbox/Grid layout
- **Font**: Custom `zc-regular.ttf` via `@font-face`
- **Server (dev)**: Python `http.server` on port 5000
- **Deployment**: Static site (publicDir: `40`)

## Project Structure
```
40/
├── index.html       # Main entry point (SEO-optimized)
├── app.js           # Application logic (artifact generation, event handling)
├── styles.css       # All styling and responsive rules
└── zc-regular.ttf   # Custom monospace font
```

## SEO Elements
- Title: "Free Online Build Planner Tool — Schematic, BOM & Workflow Generator | Svivva"
- H1: "Free Online Build Planner Tool"
- Meta description, OG tags, Twitter card, canonical URL
- JSON-LD structured data (WebApplication schema)
- 400-600 word SEO content section with internal links to svivva.com
- 5 FAQ items with keyword-rich answers
- All CTAs link to svivva.com

## Modes
- Hardware: Schematic + BOM table
- Play: Audio waveform preview
- Idea: Feasibility report + score
- Team: Collaboration flow graph
- Marketplace: Publish readiness checklist
- Build: 3D preview placeholder
