# Free Idea Comparison Tool Online

## Overview
A free, static client-side web tool by Svivva that generates mock "idea history" timelines and comparison views from user-provided concept descriptions. It serves as a single-step preview of Svivva's full Idea Engine pipeline. Built as an engineering-as-marketing tool to drive organic search traffic to svivva.com.

## Tech Stack
- HTML5, CSS3 (CSS Variables, Grid layout), Vanilla JavaScript (ES6)
- Custom font: `zc-regular.ttf`
- No backend — fully client-side
- Deployed as static site

## SEO
- Primary keyword: "idea comparison tool"
- Title: "Free Idea Comparison Tool Online — Compare Concepts Instantly | Svivva"
- Schema.org structured data (WebApplication + FAQPage)
- Open Graph and Twitter Card meta tags
- 400-600 word SEO content section below the tool
- Internal links to svivva.com throughout
- robots.txt and sitemap.xml included
- Canonical URL: https://svivva.com/tools/idea-comparison

## Project Structure
- `37/index.html` — Entry point, three-panel layout with full SEO markup
- `37/app.js` — Core logic (readiness scoring, timeline/comparison rendering, SVG flow graphs)
- `37/styles.css` — Dark-themed UI with responsive breakpoints
- `37/zc-regular.ttf` — Custom brand font
- `37/robots.txt` — Search engine crawl directives
- `37/sitemap.xml` — XML sitemap for search engines

## Running
Served via Python HTTP server on port 5000:
```
python3 -m http.server 5000 --directory 37
```

## Deployment
Configured as static deployment with `publicDir: "37"`.
