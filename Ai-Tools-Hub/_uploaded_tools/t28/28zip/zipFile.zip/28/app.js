(function () {
  'use strict';

  const MODE_MAPPING = {
    hardware: {
      step: 'Hardware pipeline — BOM / schematic preview',
      next: 'In the full workflow: part sourcing, 3D placement, revision history, and production exports.',
      artifactType: 'table',
    },
    play: {
      step: 'Svivva Play — patch / performance preview',
      next: 'In the full workflow: versioned patches, live routing, multi-device sync, and export to hardware.',
      artifactType: 'flow',
    },
    idea: {
      step: 'Idea Engine — concept report preview',
      next: 'In the full workflow: staged validation, team voting, cost estimates, and roadmap linking.',
      artifactType: 'report',
    },
    team: {
      step: 'Collaboration & permissions — setup map preview',
      next: 'In the full workflow: roles, sharing links, activity log, and approval flows.',
      artifactType: 'map',
    },
    marketplace: {
      step: 'API Marketplace — publishing preview',
      next: 'In the full workflow: versioning, usage limits, billing, and discovery.',
      artifactType: 'flow',
    },
    build: {
      step: 'B.U.I.L.D. — digital / physical flow preview',
      next: 'In the full workflow: full pipeline from idea to manufacturing with cost tracking.',
      artifactType: 'flow',
    },
  };

  function emit(name, data) {
    if (typeof window.analytics !== 'undefined' && window.analytics.track) {
      window.analytics.track(name, data);
    }
    if (typeof window.gtag === 'function') {
      window.gtag('event', name, data);
    }
    console.log('[Svivva Patch Designer]', name, data);
  }

  function generateArtifact(description, mode, constraints) {
    const mapping = MODE_MAPPING[mode] || MODE_MAPPING.play;
    const type = mapping.artifactType;
    const seed = (description + mode + JSON.stringify(constraints)).length;
    const confidence = Math.min(95, 45 + (seed % 45));

    let html = '';
    if (type === 'table') {
      html = '<div class="artifact-table"><table><thead><tr><th>Part</th><th>Qty</th><th>Role</th></tr></thead><tbody>';
      const parts = ['VCO', 'VCF', 'VCA', 'EG', 'LFO', 'Mixer'].slice(0, 3 + (seed % 3));
      parts.forEach(function (p, i) {
        html += '<tr><td>' + p + '</td><td>' + (1 + (i % 2)) + '</td><td>Preview</td></tr>';
      });
      html += '</tbody></table></div>';
    } else if (type === 'report') {
      html = 'IDEA REPORT (preview)\n\nConcept: ' + (description.slice(0, 80) || '—') + '\n\nStage: Draft\nReadiness: Preview only — full Idea Engine adds validation and roadmap.\n';
    } else if (type === 'map') {
      html = 'SETUP MAP (preview)\n\nRoles: Viewer, Editor (preview)\n\n' + (constraints.collab ? 'Collaboration size: ' + constraints.collab + '\n' : '') + 'Full Svivva adds permissions, activity log, and approval flows.';
    } else {
      html = 'PATCH / FLOW (preview)\n\n' + (description.slice(0, 120) || '—') + '\n\n[Input] → [Process] → [Output]\n(Mode: ' + mode + ')\n\nThis is one step. Full workflow adds versioning, collaboration, and production exports.';
    }

    return { html: html, confidence: confidence, mapping: mapping };
  }

  function showPreview(artifact) {
    var placeholder = document.getElementById('preview-placeholder');
    var result = document.getElementById('preview-result');
    var artifactEl = document.getElementById('preview-artifact');
    var fill = document.getElementById('confidence-fill');
    var value = document.getElementById('confidence-value');
    var mappingStatic = document.getElementById('mapping-copy');
    var mappingDynamic = document.getElementById('mapping-dynamic');

    placeholder.classList.add('hidden');
    result.classList.remove('hidden');
    artifactEl.innerHTML = artifact.html;
    artifactEl.className = 'preview-artifact artifact-' + (artifact.mapping.artifactType || 'flow');
    fill.style.width = artifact.confidence + '%';
    value.textContent = artifact.confidence + '%';

    mappingStatic.classList.add('hidden');
    mappingDynamic.classList.remove('hidden');
    mappingDynamic.innerHTML =
      '<p><strong>Step previewed:</strong> ' + artifact.mapping.step + '</p>' +
      '<p>' + artifact.mapping.next + '</p>';
  }

  function showPlaceholder() {
    document.getElementById('preview-placeholder').classList.remove('hidden');
    document.getElementById('preview-result').classList.add('hidden');
    document.getElementById('mapping-copy').classList.remove('hidden');
    document.getElementById('mapping-dynamic').classList.add('hidden');
  }

  function getConstraints() {
    return {
      budget: document.getElementById('constraint-budget').value.trim(),
      genre: document.getElementById('constraint-genre').value.trim(),
      materials: document.getElementById('constraint-materials').value.trim(),
      region: document.getElementById('constraint-region').value.trim(),
      collab: document.getElementById('constraint-collab').value.trim(),
    };
  }

  document.getElementById('brief-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var description = document.getElementById('description').value.trim();
    var mode = document.getElementById('mode').value;
    var btn = document.getElementById('btn-generate');

    if (!description) return;

    btn.disabled = true;
    emit('module_interest', { module: mode });

    setTimeout(function () {
      var constraints = getConstraints();
      var artifact = generateArtifact(description, mode, constraints);
      showPreview(artifact);
      btn.disabled = false;
      emit('preview_generated', { mode: mode, confidence: artifact.confidence });
    }, 1200);
  });

  function ctaClick(label) {
    return function () {
      emit('cta_click', { label: label });
    };
  }

  document.getElementById('cta-primary').addEventListener('click', ctaClick('primary_below_preview'));
  document.getElementById('cta-secondary').addEventListener('click', ctaClick('secondary_open_in_svivva'));
  document.getElementById('cta-bar').addEventListener('click', ctaClick('sticky_bar'));
})();
